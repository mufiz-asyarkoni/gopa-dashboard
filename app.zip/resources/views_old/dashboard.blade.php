@extends('layouts.app')

@section('content')
    @include('layouts.headers.cards', ['total_player' => $total_player])
    
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-8 mb-5 mb-xl-2">
                <div class="card bg-gradient-default shadow">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="text-uppercase text-light ls-1 mb-1">Overview</h6>
                                <h2 class="text-white mb-0">Desks Traffic</h2>
                            </div>
                            <div class="col">
                                <ul class="nav nav-pills justify-content-end">
                                    <li class="nav-item mr-2 mr-md-0" data-toggle="chart" data-target="#chart-sales" data-update='{"data":{"datasets":[{"data":[0, 20, 10, 30, 15, 40, 20, 60, 60]}]}}' data-prefix="" data-suffix="k">
                                        <a href="#" class="nav-link py-2 px-3 active" data-toggle="tab">
                                            <span class="d-none d-md-block">Month</span>
                                            <span class="d-md-none">M</span>
                                        </a>
                                    </li>
                                    <li class="nav-item" data-toggle="chart" data-target="#chart-sales" data-update='{"data":{"datasets":[{"data":[0, 20, 5, 25, 10, 30, 15, 40, 40]}]}}' data-prefix="" data-suffix="k">
                                        <a href="#" class="nav-link py-2 px-3" data-toggle="tab">
                                            <span class="d-none d-md-block">Week</span>
                                            <span class="d-md-none">W</span>
                                        </a>
                                    </li>
                                    <li class="nav-item" data-toggle="chart" data-target="#chart-sales" data-update='{"data":{"datasets":[{"data":[0, 20, 50, 25, 13, 30, 25, 60, 40]}]}}' data-prefix="" data-suffix="k">
                                        <a href="#" class="nav-link py-2 px-3" data-toggle="tab">
                                            <span class="d-none d-md-block">Day</span>
                                            <span class="d-md-none">D</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- Chart -->
                        <div class="chart">
                            <!-- Chart wrapper -->
                            <canvas id="chart-sales" class="chart-canvas"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="card shadow">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="text-uppercase text-muted ls-1 mb-1">Performance</h6>
                                <h2 class="mb-0">Total Admin Fee</h2>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- Chart -->
                        <div class="chart">
                            <canvas id="chart-orders" class="chart-canvas"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    
    <div class="container-fluid mt-5 mt-xl-4">
        <div class="header-body">
            <div class="row mb-xl-4">
                <div class="col-xl-12 col-lg-6">
                    <div class="card shadow bg-gradient-primary card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h4 class="card-title text-uppercase text-muted mt-3 text-white">Player Admin Fee Details</h4>
                                </div>
                                <div class="col-auto">
                                    <div  class="icon icon-shape bg-yellow text-white rounded-circle shadow mt-1">
                                        <a class="nav-link" href="{{ route('configuration') }}">
                                        <i class="fas fa-dollar-sign"></i>
                                        </a>
                                    </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Card Stats Player Admin Fee -->
            <div class="row">
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (1)</h5>
                                    @foreach($admin_fee1 as $fee1)
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;{{$fee1->fee_admin1}}</span>
                                    @endforeach
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-primary text-white rounded-circle shadow">
                                        <i class="fas fa-1"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (2)</h5>
                                    @foreach($admin_fee2 as $fee2)
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;{{$fee2->fee_admin2}}</span>
                                    @endforeach                                
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-pink text-white rounded-circle shadow">
                                        <i class="fas fa-2"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (3)</h5>
                                    @foreach($admin_fee3 as $fee3)
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;{{$fee3->fee_admin3}}</span>
                                    @endforeach
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-info text-white rounded-circle shadow">
                                        <i class="fa-solid fa-3"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-xl-4">
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (4)</h5>
                                    @foreach($admin_fee4 as $fee4)
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;{{$fee4->fee_admin4}}</span>
                                    @endforeach
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-red text-white rounded-circle shadow">
                                        <i class="fas fa-4"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (5)</h5>
                                    @foreach($admin_fee5 as $fee5)
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;{{$fee5->fee_admin5}}</span>
                                    @endforeach
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-green text-white rounded-circle shadow">
                                        <i class="fas fa-5"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (6)</h5>
                                    @foreach($admin_fee6 as $fee6)
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;{{$fee6->fee_admin6}}</span>
                                    @endforeach
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-orange text-white rounded-circle shadow">
                                        <i class="fa-solid fa-6"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-xl-4">
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (7)</h5>
                                    @foreach($admin_fee7 as $fee7)
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;{{$fee7->fee_admin7}}</span>
                                    @endforeach
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-dark text-white rounded-circle shadow">
                                        <i class="fas fa-7"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (8)</h5>
                                    @foreach($admin_fee8 as $fee8)
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;{{$fee8->fee_admin8}}</span>
                                    @endforeach
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-gray text-white rounded-circle shadow">
                                        <i class="fas fa-8"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (9)</h5>
                                    @foreach($admin_fee9 as $fee9)
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;{{$fee9->fee_admin9}}</span>
                                    @endforeach
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-purple text-white rounded-circle shadow">
                                        <i class="fa-solid fa-9"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @include('layouts.footers.auth')
    </div>
         
@endsection

@push('js')
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.extension.js"></script>
            <script src="https://argon-dashboard-pro-laravel.creative-tim.com/argon/vendor/chart.js/dist/Chart.min.js"></script>
        <script
            src="https://argon-dashboard-pro-laravel.creative-tim.com/argon/vendor/chart.js/dist/Chart.extension.js"></script>
        <script src="https://argon-dashboard-pro-laravel.creative-tim.com/argon/vendor/chart.js/dist/Chart.min.js"></script>
        <script
            src="https://argon-dashboard-pro-laravel.creative-tim.com/argon/vendor/chart.js/dist/Chart.extension.js"></script>
@endpush