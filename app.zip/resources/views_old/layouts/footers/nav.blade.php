<div class="row align-items-center justify-content-xl-between">
    <div class="col-xl-6">
        <div class="copyright text-center text-xl-left text-muted">
            &copy; {{ now()->year }} <a href="https://www.koonek.net/" class="font-weight-bold ml-1" target="_blank">Koonek Research</a>
        </div>
    </div>
    <div class="col-xl-6">
        <ul class="nav nav-footer justify-content-center justify-content-xl-end">
            <li class="nav-item">
                <a href="https://www.koonek.net/tentang/" class="nav-link" target="_blank">About</a>
            </li>
            <li class="nav-item">
                <a href="mailto:admin@gopa.koonek.net" class="nav-link" target="_blank">Registration</a>
            </li>
            <li class="nav-item">
                <a href="https://www.koonek.net/kontak/" class="nav-link" target="_blank">Contact Us</a>
            </li>
        </ul>
    </div>
</div>