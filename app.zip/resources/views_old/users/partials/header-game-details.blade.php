<div class="header pb-8 pt-5 pt-lg-8 d-flex align-items-center" style="background-image: url(https://images.unsplash.com/photo-1517232115160-ff93364542dd?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8Y2FzaW5vfGVufDB8fDB8fA%3D%3D&w=1000&q=80); background-size: cover; background-position: center top;">
    <!-- Mask -->
    <span class="mask bg-gradient-default opacity-8"></span>
    <!-- Header container -->
    <div class="container-fluid d-flex align-items-center">
        <div class="row">
            <div class="col-md-3 mt-xl-3 mb-3 mt-3 text-center text-xl-left"><img src="{{ asset('gopa') }}/btn_buqiang.png" height="100" width="103"></div>
            <div class="col-md-6 ml-xl--5">
                <h1 class="display-2 text-white text-center text-xl-left">{{ $title }}</h1>
                @if (isset($description) && $description)
                    <p class="text-white mt-0 mb-5 text-center text-xl-left mt-0 mb-5 pl-3 pr-3 pl-xl-0 pr-xl-0">{{ $description }}</p>
                @endif
            </div>
        </div>
    </div>
</div> 