<div class="header pb-8 pt-5 pt-lg-8 d-flex align-items-center" style="background-image: url(https://www.nbrii.com/img/bigstock-casino-gambling-poker-peopl-78562082_hu763b5a1682d53e548819a84f1b576b88_4153783_1400x575_fill_q75_h2_box_center.webp); background-size: cover; background-position: center top;">
    <!-- Mask -->
    <span class="mask bg-gradient-default opacity-8"></span>
    <!-- Header container -->
    <div class="container-fluid d-flex align-items-center">
        <div class="row">
            <div class="col-md-4 mt-xl--5 mb--3 mt--5 text-center text-xl-left"><img src="{{ asset('gopa') }}/full_effect24.png" height="233" width="200"></div>
            <div class="col-md-5 ml-xl--3">
                <h1 class="display-2 text-white text-center text-xl-left">{{ $title }}</h1>
                @if (isset($description) && $description)
                    <p class="text-white text-center text-xl-left mt-0 mb-5 pl-3 pr-3 pl-xl-0 pr-xl-0">{{ $description }}</p>
                @endif
            </div>
        </div>
    </div>
</div> 