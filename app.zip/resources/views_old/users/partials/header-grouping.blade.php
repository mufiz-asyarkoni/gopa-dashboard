<div class="header pb-8 pt-5 pt-lg-8 d-flex align-items-center" style="background-image: url(https://merahputih.com/media/29/ea/66/29ea664747f8a298ab13e9c49e5c17c1.jpg); background-size: cover; background-position: center top;">
    <!-- Mask -->
    <span class="mask bg-gradient-default opacity-8"></span>
    <!-- Header container -->
    <div class="container-fluid d-flex align-items-center">
        <div class="row">
            <div class="col-md-3 mt-xl--2 mb-3 mt-2 text-center text-xl-left"><img src="{{ asset('gopa') }}/full_effect28.png" height="169" width="194"></div>
            <div class="col-md-6 ml-xl-3">
                <h1 class="display-2 text-white text-center text-xl-left">{{ $title }}</h1>
                @if (isset($description) && $description)
                    <p class="text-white mt-0 mb-5 text-center text-xl-left mt-0 mb-5 pl-3 pr-3 pl-xl-0 pr-xl-0">{{ $description }}</p>
                @endif
            </div>
        </div>
    </div>
</div> 