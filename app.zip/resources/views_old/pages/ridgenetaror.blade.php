<?php
        $userLength1 = 1; //mendefinisikan panjang string (1)
        $userLength2 = 4; //mendefinisikan panjang string (2)
        $userLength3 = 1; //mendefinisikan panjang string (3)
        $userLength4 = 2; //mendefinisikan panjang string (4)
        $permitted_chars1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; //mendefinisikan string set pertama
        $permitted_chars2 = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ"; //mendefinisikan string set kedua
        $permitted_chars3 = "123"; //mendefinisikan string set ketiga
        $permitted_chars4 = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ"; //mendefinisikan string set keempat
        
        //mendapatkan calon user_rid dari charset untuk divalidasi
        $getUserRID = '1C'.substr(str_shuffle($permitted_chars1), 0, $userLength1).substr(str_shuffle($permitted_chars2), 0, $userLength2).'06'.substr(str_shuffle($permitted_chars3), 0, $userLength3).substr(str_shuffle($permitted_chars4), 0, $userLength4); 
        echo $getUserRID; //menampilkan user_rid yang sudah digenerate //output ex: 1CPE1U0063K9 1CUDTYM0622Q
?>