@extends('layouts.app-blacklist')

@section('content')
    @include('users.partials.header-blacklist', [
        'title' => __('Coming Soon'),
        'description' => __('On this page you can manage blacklisted players'),
        'class' => 'col-lg-19 pr-5 pl-5 pr-xl-0 pl-xl-3'
    ])   
    
            <div class="container-fluid mt--8">
            <div class="row">
                <div class="col">
                    <div class="card bg-white shadow pl-xl-4 pr-xl-4 pl-3 pr-3">
                        <form method="get">
                        <div class="card-header bg-transparent">
                            
                            <div class="row align-items-center">
                                <h6 class="heading-small text-muted mb-4">Player Filtering</h6>
                            </div>
                            
                            <div class="row align-items-center">
                                <div class="input-group mb-4">
                                    <select class="form-control">
                                      <option>Grouping Select</option>
                                      <option><i class="ni ni-circle-08"></i>Group 1</option>
                                      <option>Group 2</option>
                                    </select>
                                </div>
                            </div>
                            
                        <div class="row align-items-center">
                                <div class="input-group mb-3">
                                  <input type="text" name="search" class="form-control" value="{{request('search')}}" placeholder="Nickname/Marker/Game ID" aria-label="Nickname/Marker/Game ID" aria-describedby="button-addon2">
                                  <div class="input-group-append">
                                    <button class="btn btn-outline-primary" type="submit" id="button-addon2"><span class="btn-inner--icon"><i class="ni ni-send"></i></button>
                                  </div>
                                </div>
                            </div>
                        </div>
                        </form>
                    
                    </div>
                </div>
            </div>
            </div>

    
@endsection

@push('js')
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.extension.js"></script>
@endpush