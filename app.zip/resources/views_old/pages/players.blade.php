@extends('layouts.app-players')

@section('content')
    @include('users.partials.header-players', [
        'title' => __('To') . ' '. auth()->user()->name,
        'description' => __('On this page you can add, delete, edit, and view player data in the game.'),
        'class' => 'col-lg-7 pr-5 pl-5 pr-xl-3 pl-xl-3'
    ])   
    <div class="container-fluid mt--8">
    <div class="header-body">
        <!-- Card stats -->
        <div class="row">
            <div class="col-xl-3 col-lg-6">
                <div class="card bg-white shadow card-stats mb-4 mb-xl-0">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <h5 class="card-title text-uppercase text-muted mb-0">Players <small>(ID)</small></h5>
                                <span class="h2 font-weight-bold mb-0">{{$count_player}}</span>
                            </div>
                            <div class="col-auto">
                                <div class="icon icon-shape bg-green text-white rounded-circle shadow">
                                    <i class="fas fa-users"></i>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            
            <div class="col-xl-6 col-lg-6">
                <div class="card bg-white shadow card-stats mb-4 mb-xl-0">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <h5 class="card-title text-uppercase text-muted mb-0">Scores</h5>
                                <span class="h2 font-weight-bold mb-0">0</span>
                            </div>
                            <div class="col-auto">
                                <div class="icon icon-shape bg-gray text-white rounded-circle shadow">
                                    <i class="fas fa-gem"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-3 col-lg-6">
                <div class="card bg-white shadow card-stats mb-4 mb-xl-0">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <h5 class="card-title text-uppercase text-muted mb-0">Update</h5>
                                <span class="h2 font-weight-bold mb-0"><?php echo date("d-m"); ?></span>
                            </div>
                            <div class="col-auto">
                                <div class="icon icon-shape bg-info text-white rounded-circle shadow">
                                    <i class="fas fa-calendar"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    
            <div class="container-fluid mt-3">
            <div class="row">
                <div class="col">
                    <div class="card bg-white shadow pl-xl-4 pr-xl-4 pl-3 pr-3">
                        <form method="get">

                             <div class="card-header bg-transparent">
                            <div class="row align-items-center">
                                <h6 class="heading-small text-muted mb-4">Player Filtering</h6>
                            </div>


                            <div class="row align-items-center">
                                <div class="input-group mb-4">
                                <select class="form-control" name="group">
                                    <option value="">Grouping Select</option>
                                    @foreach($group as $groups)
                                    <option value="{{$groups->id}}"><i class="ni ni-circle-08"></i>{{$groups->name}}</option>
                                    @endforeach
                                </select>
                                </div>
                            </div>
                            
                        <div class="row align-items-center">
                                <div class="input-group mb-3">
                                  <input type="text" name="search" value="{{request('search')}}" class="form-control" placeholder="Nickname/Marker/Game ID" aria-label="Nickname/Marker/Game ID" aria-describedby="button-addon2">
                                  <div class="input-group-append">
                                    <button class="btn btn-outline-primary" type="submit" id="button-addon2"><span class="btn-inner--icon"><i class="ni ni-send"></i></button>
                                  </div>
                                </div>
                            </div>
                        </div>
                        </form>
                    
                    </div>
                </div>
            </div>
            </div>

        <div class="container-fluid mt-3">
            <div class="row">
                <div class="col">
                    <div class="card bg-white shadow">
                            @if (session('status'))
                                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                    {{ session('status') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            @endif
                        <div class="card-header bg-transparent">
                            <div class="row align-items-center">
                                <div class="col-7">
                                    <h3 class="mb-0">Player Data Table</h3>
                                </div>
                                <div class="col-4 ml-xl-6 text-right">
                                    <a href="{{ route('addplayers') }}" class="btn btn-sm btn-primary" >Add Player <span class="btn-inner--icon"><i class="ni ni-fat-add"></i></a>
                                </div>
                            </div>
                        </div>
                
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col" class="sort" data-sort="name">Number</th>
                                        <th scope="col" class="sort" data-sort="avatar">Avatar</th>
                                        <th scope="col" class="sort" data-sort="nickname">Nickname</th>
                                        <th scope="col" class="sort" data-sort="marker">Marker</th>
                                        <th scope="col" class="sort" data-sort="user_id">Game ID</th>
                                        <th scope="col" class="sort" data-sort="desk">Desks</th>
                                        <th scope="col" class="sort" data-sort="fraction">Score</th>
                                        <th scope="col" class="sort" ></th>
                                    </tr>
                                </thead>

                                <tbody class="list">
                                    @php
                                        $index = 1;
                                        $page = request('page') ?? 1;
                                    @endphp
                                    
                                    @if($group_player)
                                    @foreach($group_player as $player)
                                    <tr>
                                        <th>
                                            <button type="button" class="btn btn-secondary btn-sm">@if($page != 1) {{(($page-1)*15)+$index}} @else {{$index}} @endif</button>
                                        </th>
                                        <td class="media align-items-center">
                                            <a href="#" class="avatar rounded-circle mr-3">
                                            <img alt="Image placeholder" src="{{$player->player->avatar1}}">
                                            </a>
                                        </td>
                                        <td>
                                            {{$player->player->nickname1}}
                                        </td>
                                        <td>
                                            {{$player->player->marker1}}
                                        </td>
                                        <td>
                                            <a type="button" class="btn btn-success btn-sm" href="{{ route('viewplayers', ['player' => $player->player->id]) }}" >{{$player->player->game_id1}}</a>
                                        </td>
                                        <td>
                                        {{$player->player->desks1}}
                                        </td>
                                        <td class="score">
                                        {{$player->player->score1}}
                                        </td>
                                        <td class="text-center">
                                            <div class="dropdown">
                                                <a class="btn btn-sm btn-icon-only text-bold" href="#" role="button"
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                                    <i class="fas fa-bars"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-hand">
                                                    <a class="dropdown-item" href="viewplayers/{{$player->player->id}}">View</a>
                                                    <a class="dropdown-item" href="editplayers/{{$player->player->id}}">Edit</a>
                                                    <button class="dropdown-item triggerDelete" data-id="{{$player->player->id}}">Delete</button>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    @php
                                    $index++;
                                    @endphp
                                    @endforeach
                                    @else
                                    @foreach($players2 as $players)
                                    @if(count($players) > 1)
                                    <tr>
                                        <th>
                                            <button type="button" class="btn btn-secondary btn-sm">@if($page != 1) {{(($page-1)*15)+$index}} @else {{$index}} @endif</button>
                                        </th>
                                        <td class="media align-items-center">
                                            <a href="#" class="avatar rounded-circle mr-3">
                                            <img alt="Image placeholder" src="{{$players[0]->avatar1}}">
                                            </a>
                                        </td>
                                        <td>
                                            {{$players[0]->nickname1}}
                                        </td>
                                        <td>
                                            {{$players[0]->marker1}}
                                        </td>
                                        <td>
                                            @foreach($players as $player)
                                            
                                            <a type="button" class="btn btn-success btn-sm" href="{{ route('viewplayers', ['player' => $player->id]) }}" >{{$player->game_id1}}</a>
                                            
                                            @endforeach
                                        </td>
                                        <td>
                                        {{$players[0]->desks1}}
                                        </td>
                                        <td class="score">
                                        {{$players[0]->score1}}
                                        </td>
                                        <td class="text-center">
                                            <div class="dropdown">
                                                <a class="btn btn-sm btn-icon-only text-bold" href="#" role="button"
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                                    <i class="fas fa-bars"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                    <a class="dropdown-item" href="viewplayers/{{$players[0]->id}}">View</a>
                                                    <a class="dropdown-item" href="editplayers/{{$players[0]->id}}">Edit</a>
                                                    <button class="dropdown-item triggerDelete" data-id="{{$players[0]->id}}">Delete</button>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    @else
                                    @foreach($players as $player)
                                    <tr>
                                        <th>
                                            <button type="button" class="btn btn-secondary btn-sm">@if($page != 1) {{(($page-1)*15)+$index}} @else {{$index}} @endif</button>
                                        </th>
                                        <td class="media align-items-center">
                                            <a href="#" class="avatar rounded-circle mr-3">
                                            <img alt="Image placeholder" src="{{$player->avatar1}}">
                                            </a>
                                        </td>
                                        <td>
                                            {{$player->nickname1}}
                                        </td>
                                        <td>
                                            {{$player->marker1}}
                                        </td>
                                        <td>
                                            <a type="button" class="btn btn-success btn-sm" href="{{ route('viewplayers', ['player' => $player->id]) }}" >{{$player->game_id1}}</a>
                                        </td>
                                        <td>
                                        {{$player->desks1}}
                                        </td>
                                        <td class="score">
                                        {{$player->score1}}
                                        </td>
                                        <td class="text-center">
                                            <div class="dropdown">
                                                <a class="btn btn-sm btn-icon-only text-bold" href="#" role="button"
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                                                    <i class="fas fa-bars"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-hand">
                                                    <a class="dropdown-item" href="viewplayers/{{$player->id}}">View</a>
                                                    <a class="dropdown-item" href="editplayers/{{$players[0]->id}}">Edit</a>
                                                    <button class="dropdown-item triggerDelete" data-id="{{$player->id}}">Delete</button>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    @endforeach
                                    @endif
                                    @php
                                    $index++;
                                    @endphp
                                    @endforeach
                                    @endif
                                </tbody>
                            </table>
                        </div>
                        
                        <!--Pagination Section-->
                        <div class="card-footer py-4">
                            <nav aria-label="...">
                                <ul class="pagination justify-content-end mb-0">
                                    
                                    @if($page != 1)
                                    <li class="page-item">
                                        <a class="page-link" href="?page={{$page-1}}" tabindex="-1">
                                            <i class="fas fa-angle-left"></i>
                                            <span class="sr-only">Previous</span>
                                        </a>
                                    </li>
                                    @endif

                                    @php
                                    $init = 1;
                                    $continues = 1;

                                    if($total_page == 1){
                                        $init = 1;
                                        $continues = 1;
                                    }elseif($total_page > 3 && $page <= 3){
                                        $init = 1;
                                        $continues = 3;
                                    }elseif($page == $total_page){
                                        $init = $page-3;
                                        $continues = $page-1;
                                    }else{
                                        $init = $page-2;
                                        $continues = $page;
                                    }
                                    @endphp

                                    @for($i=$init;$i<=$continues;$i++)
                                    <li class="page-item @if($page == $i) active @endif">
                                        <a class="page-link" href="?page={{$i}}">{{$i}}</a>
                                    </li>
                                    @endfor

                                    @if($total_page>4)
                                    <li class="page-item @if($page == $total_page) active @endif">
                                        <a class="page-link" href="?page={{$total_page}}">{{$total_page}}</a>
                                    </li>
                                    @endif
                                    
                                    @if($page != $total_page)
                                    <li class="page-item">
                                        <a class="page-link" href="?page={{$page+1}}">
                                            <i class="fas fa-angle-right"></i>
                                            <span class="sr-only">Next</span>
                                        </a>
                                    </li>
                                    @endif
                                   
                                </ul>
                            </nav>
                        </div>
                        
                    </div>
                </div>
            </div>
            @include('layouts.footers.auth')
        </div>
        
    </div>
    
    <!--Delete Modal Notification Section-->
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">GOPA Dashboard</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
            <div class="modal-body">
                Are you sure you want to delete this player?
            </div>
            <form method="post" id="form_delete">
                @csrf
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close </button>
                    <button type="submit" class="btn btn-warning">Delete <i class="fas fa-trash"></i></button>
                </div>
            </form>
            </div>
        </div>
    </div>

@endsection

@push('js')
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.extension.js"></script>

    <script>
        $(".triggerDelete").click(function () {
            var id = $(this).data('id');
            $('#deleteModal').modal("show");
            $('#form_delete').attr('action', 'player/delete/'+id);
        });
    </script>
@endpush