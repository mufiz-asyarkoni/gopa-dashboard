@extends('layouts.app-statements')

@foreach($statement_player as $player)
<title>Desk No {{$player->desk_id}} · GOPA Dashboard</title>
@endforeach

@section('content')
    @include('users.partials.header-statements', [
        'title' => __('Hello') . ' '. auth()->user()->name,
        'description' => __('On this page you can see details of the games played by your players.'),
        'class' => 'col-lg-7'
    ])   
    
        <div class="container-fluid mt--8">
            <div class="row justify-content-center">
                <div class=" col ">
                    <div class="card">
                        
                        @foreach($statement_player as $player)
                        <!--Desk Number Header Section-->
                        <div class="card-header bg-transparent">
                            <h3 class="mb-0">Desk No {{$player->desk_id}}</h3>
                        </div>
                        @endforeach
                        
                        <!--Player Information Section-->
                         <div class="card-body">
                            <h6 class="heading-small text-muted mb-4">Player information</h6>
                            <div class="row players-information">
                                
                                @foreach($statement_player as $player)
                                <div class="col-lg-4 col-md-6">
                                    <a href= "{{ route('viewplayers', ['player' => $player->id]) }}">
                                    <button  type="button" class="btn-icon-clipboard" data-clipboard-text="active-40"
                                        title="View player details">
                                        <div>
                                            <div class="avatar rounded-circle mr-0">
                                            <img alt="Image placeholder" src="{{$player->player->avatar1}}">
                                            </div>
                                            <span><h5>{{$player->player->nickname1}}</h5>Game ID: {{$player->player->game_id1}}<br/>Score: {{$player->player->score1}}<br/><small>IP- {{$player->ip}}</small> </span>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                @endforeach
                                
                            </div>
                        </div>
                        
                        <!--Game Desk Information Section-->
                        <div class="card-body">
                            <h6 class="heading-small text-muted mb-4">Game Desk Information</h6>
                            <div class="row players-information">
                                
                                
                                <div class="col-lg-6 col-md-6">
                                    <a data-toggle="modal" data-target="#modal-notification">
                                    <button  type="button" class="btn-icon-clipboard" data-clipboard-text="active-40"
                                        title="View round details">
                                        <div>
                                            <h3><i class="ni ni-button-play"></i>&nbsp; Round: 1</h3>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                
                                
                                <div class="col-lg-6 col-md-6">
                                    <a data-toggle="modal" data-target="#modal-notification">
                                    <button type="button" class="btn-icon-clipboard" data-clipboard-text="air-baloon"
                                        title="View round details">
                                        <div>
                                            <h3><i class="ni ni-button-play"></i>&nbsp; Round: 2</h3>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                
                                <div class="col-lg-6 col-md-6">
                                    <a data-toggle="modal" data-target="#modal-notification">
                                    <button type="button" class="btn-icon-clipboard" data-clipboard-text="album-2"
                                        title="View round details">
                                        <div>
                                            <h3><i class="ni ni-button-play"></i>&nbsp; Round: 3</h3>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <a data-toggle="modal" data-target="#modal-notification">
                                    <button type="button" class="btn-icon-clipboard" data-clipboard-text="align-center"
                                        title="View round details">
                                        <div>
                                            <h3><i class="ni ni-button-play"></i>&nbsp; Round: 4</h3>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <a data-toggle="modal" data-target="#modal-notification">
                                    <button type="button" class="btn-icon-clipboard" data-clipboard-text="align-left-2"
                                        title="View round details">
                                        <div>
                                            <h3><i class="ni ni-button-play"></i>&nbsp; Round: 5</h3>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <a data-toggle="modal" data-target="#modal-notification">
                                    <button type="button" class="btn-icon-clipboard" data-clipboard-text="ambulance"
                                        title="View round details">
                                        <div>
                                            <h3><i class="ni ni-button-play"></i>&nbsp; Round: 6</h3>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                <div class="col-lg-6 col-md-6">
                                    <a data-toggle="modal" data-target="#modal-notification">
                                    <button type="button" class="btn-icon-clipboard" data-clipboard-text="app"
                                        title="View round details">
                                        <div>
                                            <h3><i class="ni ni-button-play"></i>&nbsp; Round: 7</h3>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                
                                <div class="col-lg-6 col-md-6">
                                    <a data-toggle="modal" data-target="#modal-notification">
                                    <button type="button" class="btn-icon-clipboard" data-clipboard-text="archive-2"
                                        title="View round details">
                                        <div>
                                            <h3><i class="ni ni-button-play"></i>&nbsp; Round: 8</h3>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                
                                <div class="col-lg-6 col-md-6">
                                    <a data-toggle="modal" data-target="#modal-notification">
                                    <button type="button" class="btn-icon-clipboard" data-clipboard-text="atom"
                                        title="View round details">
                                        <div>
                                            <h3><i class="ni ni-button-play"></i>&nbsp; Round: 9</h3>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                
                                <div class="col-lg-6 col-md-6">
                                    <a data-toggle="modal" data-target="#modal-notification">
                                    <button type="button" class="btn-icon-clipboard" data-clipboard-text="atom"
                                        title="View round details">
                                        <div>
                                            <h3><i class="ni ni-button-play"></i>&nbsp; Round: 10</h3>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
        @include('layouts.footers.auth')
    </div>
    
        <div class="modal fade" id="modal-notification" tabindex="-1" role="dialog" aria-labelledby="modal-notification"
            aria-hidden="true">
            <div class="modal-dialog modal-danger modal-dialog-centered modal-" role="document">
                <div class="modal-content bg-gradient-primary">

                    <div class="modal-header">
                        <h6 class="modal-title" id="modal-title-notification">Round 1: Desk No 106004</h6>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        <h4 class="text-center heading mt--4 mb-4">Round Details Information</h4>
                        <div class="row players-information">
                            
                                <div class="col-lg-4 col-md-4">
                                    <a href= "{{ route('viewplayers', ['player' => $player->id]) }}">
                                    <button  type="button" class="btn-icon-clipboard" data-clipboard-text="active-40"
                                        title="View player details">
                                        <div>
                                            <a>ID: {{$player->player->game_id1}}<br/><b>{{$player->player->score1}}</b></a>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <a href= "{{ route('viewplayers', ['player' => $player->id]) }}">
                                    <button  type="button" class="btn-icon-clipboard" data-clipboard-text="active-40"
                                        title="View player details">
                                        <div>
                                            <a>ID: {{$player->player->game_id1}}<br/><b>{{$player->player->score1}}</b></a>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <a href= "{{ route('viewplayers', ['player' => $player->id]) }}">
                                    <button  type="button" class="btn-icon-clipboard" data-clipboard-text="active-40"
                                        title="View player details">
                                        <div>
                                            <a>ID: {{$player->player->game_id1}}<br/><b>{{$player->player->score1}}</b></a>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <a href= "{{ route('viewplayers', ['player' => $player->id]) }}">
                                    <button  type="button" class="btn-icon-clipboard" data-clipboard-text="active-40"
                                        title="View player details">
                                        <div>
                                            <a>ID: {{$player->player->game_id1}}<br/><b>{{$player->player->score1}}</b></a>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <a href= "{{ route('viewplayers', ['player' => $player->id]) }}">
                                    <button  type="button" class="btn-icon-clipboard" data-clipboard-text="active-40"
                                        title="View player details">
                                        <div>
                                            <a>ID: {{$player->player->game_id1}}<br/><b>{{$player->player->score1}}</b></a>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                <div class="col-lg-4 col-md-4">
                                    <a href= "{{ route('viewplayers', ['player' => $player->id]) }}">
                                    <button  type="button" class="btn-icon-clipboard" data-clipboard-text="active-40"
                                        title="View player details">
                                        <div>
                                            <a>ID: {{$player->player->game_id1}}<br/><b>{{$player->player->score1}}</b></a>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                        </div>
                    </div>

                    <div class="modal-footer mt--4">
                        <button type="button" class="btn btn-link text-white ml-auto"
                            data-dismiss="modal">Close</button>
                    </div>

                </div>
            </div>
        </div>
    
@endsection