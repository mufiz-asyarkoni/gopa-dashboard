@extends('layouts.app-gamedetails')

@section('content')
    @include('users.partials.header-game-details', [
        'title' => __('To') . ' '. auth()->user()->name,
        'description' => __('On this page you can see the details of the games played by each player in real time.'),
        'class' => 'col-lg-7 pr-5 pl-5 pr-xl-3 pl-xl-3'
    ])   

            <div class="container-fluid mt--8">
            <div class="row">
                <div class="col">
                    <div class="card bg-white shadow pl-xl-4 pr-xl-4 pl-3 pr-3">
                        <form method="get">
                        <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                                <h6 class="heading-small text-muted mb-4">Player Filtering</h6>
                            </div>
                        <div class="row align-items-center">
                                <div class="input-group mb-3">
                                  <input type="text" name="search" class="form-control" value="{{request('search')}}" placeholder="Nickname/Marker/Game ID" aria-label="Nickname/Marker/Game ID" aria-describedby="button-addon2">
                                  <div class="input-group-append">
                                    <button class="btn btn-outline-primary" type="button" id="button-addon2"><span class="btn-inner--icon"><i class="ni ni-send"></i></button>
                                  </div>
                                </div>
                            </div>
                        </div>
                        </form>
                    
                    </div>
                </div>
            </div>
            </div>

        <div class="container-fluid mt-3">
            <div class="row">
                <div class="col">
                    <div class="card bg-white shadow">
                    
                        <div class="card-header border-0">
                            <h3 class="mb-0">Player Game Details Table</h3>
                        </div>
                
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col" class="sort" data-sort="name">No.</th>
                                        <th scope="col" class="sort" data-sort="avatar">Avatar</th>
                                        <th scope="col" class="sort" data-sort="nickname">Nickname</th>
                                        <th scope="col" class="sort" data-sort="user_id">Game ID</th>
                                        <th scope="col" class="sort" data-sort="user_id">Game ID (►)</th>
                                        <th scope="col" class="sort" data-sort="desk">Score Final</th>
                                        <th scope="col" class="sort" data-sort="fraction">Admin Fee</th>
                                        <th scope="col" class="sort" data-sort="fraction">Desk Number</th>
                                        <th scope="col" class="sort" data-sort="fraction">End Time</th>
                                    </tr>
                                </thead>

                                <tbody class="list">
                                    @php
                                    $index = 1;
                                    @endphp
                                    @foreach($players2 as $players)
                                    @if(count($players) > 1)
                                    <tr>
                                        <th>
                                            <button type="button" class="btn btn-secondary btn-sm">{{$index}}</button>
                                        </th>
                                        <td class="media align-items-center">
                                            <a href="#" class="avatar rounded-circle mr-3">
                                            <img alt="Image placeholder" src="{{$players[0]->avatar1}}">
                                            </a>
                                        </td>
                                        <td>
                                            {{$players[0]->nickname1}}
                                        </td>
                                        <td>
                                            @foreach($players as $player)
                                            <button type="button" class="btn btn-success btn-sm">{{$player->game_id1}}</button>
                                            @endforeach
                                        </td>
                                        <td>
                                            @foreach($players as $player)
                                            <button type="button" class="btn btn-success btn-sm">{{$player->game_id1}}</button>
                                            @endforeach
                                        </td>
                                        <td>
                                        {{$players[0]->score1}}
                                        </td>
                                        <td class="score">
                                        {{$players[0]->feeadmin1}}
                                        </td>
                                        <td class="score">
                                        {{$players[0]->desks1}}
                                        </td>
                                        <td>
                                        <?php echo date("Y-m-d H:i:s", 1658669453); ?>
                                        </td>
                                    </tr>
                                    @else
                                    @foreach($players as $player)
                                    <tr>
                                        <th>
                                            <button type="button" class="btn btn-secondary btn-sm">{{$index}}</button>
                                        </th>
                                        <td class="media align-items-center">
                                            <a href="#" class="avatar rounded-circle mr-3">
                                            <img alt="Image placeholder" src="{{$player->avatar1}}">
                                            </a>
                                        </td>
                                        <td>
                                            {{$player->nickname1}}
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-success btn-sm">{{$player->game_id1}}</button>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-success btn-sm">{{$player->game_id1}}</button>
                                        </td>
                                        <td>
                                        {{$player->score1}}
                                        </td>
                                        <td>
                                        {{$player->feeadmin1}}
                                        </td>
                                        <td>
                                        {{$player->desks1}}
                                        </td>
                                        <td>
                                        <?php echo date("Y-m-d H:i:s", 1658669453); ?>
                                        </td>
                                    </tr>
                                    @endforeach
                                    @endif
                                    @php
                                    $index++;
                                    @endphp
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        
                        <!--Pagination Section-->
                        <div class="card-footer py-4">
                            <nav aria-label="...">
                                <ul class="pagination justify-content-end mb-0">
                                    
                                    <!--
                                    <li class="page-item">
                                        <a class="page-link" href="#" tabindex="-1">
                                            <i class="fas fa-angle-left"></i>
                                            <span class="sr-only">Previous</span>
                                        </a>
                                    </li>
                                    -->
                                    
                                    <li class="page-item">
                                        <a class="page-link" href="?page=1">1</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=2">2 <span class="sr-only">(current)</span></a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=3">3</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=4">4</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=5">5</a>
                                    </li>
                                    <li class="page-item">
                                        <a class="page-link" href="?page=6">6</a>
                                    </li>
                                    
                                    <!--
                                    <li class="page-item">
                                        <a class="page-link" href="#">
                                            <i class="fas fa-angle-right"></i>
                                            <span class="sr-only">Next</span>
                                        </a>
                                    </li>
                                    -->
                                </ul>
                            </nav>
                        </div>
                        
                    </div>
                </div>
            </div>
            @include('layouts.footers.auth')
        </div>
        
    </div>
    

@endsection

@push('js')
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.extension.js"></script>
@endpush