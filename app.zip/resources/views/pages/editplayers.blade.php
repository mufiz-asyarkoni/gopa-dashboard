@extends('layouts.app-players')
<title>Edit Player {{$player->game_id1}} · GOPA Dashboard</title>

@section('content')
    @include('users.partials.header-players', [
        'title' => __('Hello') . ' '. auth()->user()->name,
        'description' => __('On this page you can change the score or nickname of each player.'),
        'class' => 'col-lg-7'
    ])   
    
    <div class="container-fluid mt--8">
        <div class="row">
            <div class="col-xl-4 order-xl-2 mb-4 mb-xl-0">
                <div class="card card-profile shadow">
                    <div class="row justify-content-center">
                        <div class="col-lg-3 order-lg-2 mt-4">
                            <div class="card-profile-image">
                                <a href="#">
                                    <img src="{{$player->avatar1}}" class="rounded-circle">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body pt-0 pt-md-1">
                        <div class="row">
                            <div class="col">
                                <div class="card-profile-stats d-flex justify-content-center mt-md-5">
                                    <div class="text-center">

                                        <h3>
                                            <span class="font-weight-light"></span>
                                        </h3>
            
                                        <hr class="my-4" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-8 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h3 class="mb-0">&emsp;<i class="fas fa-user-check"></i>&emsp;Edit Player</h3>
                                <div class="col-xl-9 col-3 text-right">
                                    <a href="{{ route('viewplayers', ['player' => $player->id]) }}" class="btn btn-sm btn-primary" >View Player&emsp;<span class="btn-inner--icon"><i class="ni ni-single-02"></i></a>
                                </div>
                        </div>
                    </div>
                    <div class="card-body">
                        
                        <form method="post" action="{{ route('player.update', ['player' => $player->id]) }}" autocomplete="off">
                            @csrf
                            @method('put')
                            
                            <h6 class="heading-small text-muted mb-4">Player information</h6>
                            
                            @if (session('status'))
                                <div class="alert alert-info alert-dismissible fade show" role="alert">
                                    {{ session('status') }}
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            @endif


                            <div class="pl-lg-4 pr-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label">Game ID</label>
                                    <h1 class="display-3">{{$player->game_id1}}</h1>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Nickname</label>
                                    <h1 class="display-3">{{$player->nickname1}}</h1>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Edit Nickname</label>
                                    <input type="text" name="nickname1" id="input-nickname" class="form-control form-control-alternative" placeholder="Enter the nickname of the player you want to change" value="{{$player->nickname1}}" required>
                                </div>  
                                <div class="form-group">
                                    <label class="form-control-label">Marker</label>
                                    <h1 class="display-3">{{$player->marker1}}</h1>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Edit Marker</label>
                                    <input type="text" name="marker1" id="input-marker" class="form-control form-control-alternative" placeholder="Enter the marker for the player you want to change" value="{{$player->marker1}}" required>
                                </div>  
                                <div class="form-group">
                                    <label class="form-control-label">Score </label>
                                    <small>[{{ today()->day }}-{{ today()->month }}-{{ today()->year }}]</small>
                                    <h1 class="display-3">{{$player->score1}}</h1>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Change Score (+/-)</label>
                                    <input type="number" name="score1" id="input-score" class="form-control form-control-alternative" placeholder="Enter the score of the player you want to change" value="0" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Player Notes</label>
                                    <form>
                                      <textarea name="notes1" class="form-control form-control-alternative" rows="3" placeholder="Enter a special note about this player in this section" value="">{{$player->notes1}}</textarea>
                                    </form>
                                </div>
                                
                                <div class="text-left mb-4">
                                    <button type="submit " class="btn btn-success mt-4">Save Player Information&emsp;<i class="fas fa-check"></i></button>
                                </div>

                                <div class="text-center">
                                </div>
                            </div>
                        </form>
                    
                    </div>
                </div>
            </div>
        </div>
        
        @include('layouts.footers.auth')
    </div>
    
@endsection