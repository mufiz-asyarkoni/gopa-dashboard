@extends('layouts.app-statements')

@section('content')
    @include('users.partials.header-statements', [
        'title' => __('To') . ' '. auth()->user()->name,
        'description' => __('On this page you can see how the statements of each game that have been played by the player.'),
        'class' => 'col-lg-7 pr-5 pl-5 pr-xl-3 pl-xl-3'
    ])   
    
        <form>
            <div class="container-fluid mt--8">
                <div class="header-body">
                    <!-- Card stats -->
                    <div class="row">
                        <div class="col-xl-6 col-lg-6">
                            <div class="card bg-white shadow card-stats mb-4 mb-xl-0">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <label for="example-datetime-local-input" class="form-control-label">Start Date</label>
                                                <input class="form-control" type="datetime-local" value="{{ now() }}" name="create_time" id="example-datetime-local-input">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-xl-6 col-lg-6">
                            <div class="card bg-white shadow card-stats mb-4 mb-xl-0">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <label for="example-datetime-local-input" class="form-control-label">End Date</label>
                                                <input class="form-control" type="datetime-local" value="{{ now() }}" name="end_time" id="example-datetime-local-input">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="container-fluid mt-3">
                <div class="row">
                    <div class="col">
                        <div class="card bg-white shadow pl-3 pr-3">
                            <div class="card-header bg-transparent">
                                <div class="row align-items-center">
                                    <h6 class="heading-small text-muted mb-4">Desk Filtering</h6>
                                </div>
                            <div class="row align-items-center">
                                    <div class="input-group mb-4">
                                    <input type="text" class="form-control" placeholder="Desk Number" name="desk_no" value="{{request('desk_no') ?? ''}}" aria-label="Recipient's username" aria-describedby="button-addon2">
                                    <div class="input-group-append">
                                        <button class="btn btn-outline-primary" type="submit" id="button-addon2"><span class="btn-inner--icon"><i class="ni ni-send"></i></button>
                                    </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    
        <div class="container-fluid mt-3">
            <div class="row">
                <div class="col">
                    <div class="card bg-white shadow">
                        <div class="card-header border-0">
                            <h3 class="mb-0">Statements Data Table</h3>
                        </div>

                        <div class="table-responsive">
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col" class="sort" data-sort="name">No.</th>
                                        <th scope="col" class="sort" data-sort="budget">Room ID</th>
                                        <th scope="col" class="sort" data-sort="budget">Desk Number</th>
                                        <th scope="col" class="sort" data-sort="status">Play Time</th>
                                        <th scope="col" class="sort" data-sort="status">End Time</th>
                                        <th scope="col" class="sort" data-sort="completion">Operate</th>
                                        <th scope="col" class="sort" data-sort="completion">Details</th>
                                    </tr>
                                </thead>
                                <tbody class="list">
                                    @php
                                        $index = 1;
                                        $page = request('page') ?? 1;
                                    @endphp

                                    @foreach($statements as $statement)
                                    <tr>
                                        <th>
                                            <button type="button" class="btn btn-secondary btn-sm">@if($page != 1) {{(($page-1)*15)+$index}} @else {{$index}} @endif</button>
                                        </th>
                                        <td>
                                            {{$statement->room_id}}
                                        </td>
                                        <td>
                                            {{$statement->desk_no}}
                                        </td>
                                        <td>
                                            {{$statement->create_time}}
                                        </td>
                                        <td>
                                            {{$statement->end_time}}
                                        </td>
                                        <td>
                                            @if($statement->status == "completed")
                                            <span class="badge badge-dot mr-4">
                                            <i class="bg-success"></i>
                                            <span class="status">{{$statement->status}}</span>
                                            </span>
                                            @else
                                            <span class="badge badge-dot mr-4">
                                            <i class="bg-danger"></i>
                                            <span class="status">abortive</span>
                                            </span>
                                            @endif
                                        </td>
                                        <td class="text-center">
                                            <div class="dropdown">
                                                <a class="btn btn-sm btn-icon-only text-bold" href="#" role="button"
                                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                    <i class="fas fa-bars"></i>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-right dropdown-menu-arrow">
                                                    <a class="dropdown-item" href="{{ route('viewstatements', ['statement' => $statement->id]) }}">View</a>
                                                    <!--
                                                    <a class="dropdown-item" href="{{ route('viewstatements', ['statement' => $statement->id]) }}">View</a>
                                                    -->
                                                    <button class="dropdown-item triggerDelete" data-id="{{$statement->id}}">Delete</button>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    @php
                                    $index++;
                                    @endphp
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <!--Pagination Section-->
                        <div class="card-footer py-4">
                            <nav aria-label="...">
                                <ul class="pagination justify-content-end mb-0">
                                    
                                @if($page != 1)
                                <li class="page-item">
                                    <a class="page-link" href="?page={{$page-1}}" tabindex="-1">
                                        <i class="fas fa-angle-left"></i>
                                        <span class="sr-only">Previous</span>
                                    </a>
                                </li>
                                @endif
                                
                                @php
                                    $init = 1;
                                    $continues = 1;

                                    if($total_page == 1 || $total_page <= 3 && $page <= 3){
                                        $init = 1;
                                        $continues = $total_page;
                                    }elseif($total_page > 3 && $page <= 3){
                                        $init = 1;
                                        $continues = 3;
                                    }elseif($page == $total_page){
                                        $init = $page-3;
                                        $continues = $page-1;
                                    }else{
                                        $init = $page-2;
                                        $continues = $page;
                                    }
                                @endphp

                                @for($i=$init;$i<=$continues;$i++)
                                <li class="page-item @if($page == $i) active @endif">
                                    <a class="page-link" href="?page={{$i}}">{{$i}}</a>
                                </li>
                                @endfor

                                @if($total_page>4)
                                <li class="page-item @if($page == $total_page) active @endif">
                                    <a class="page-link" href="?page={{$total_page}}">{{$total_page}}</a>
                                </li>
                                @endif
                                
                                @if($page != $total_page)
                                <li class="page-item">
                                    <a class="page-link" href="?page={{$page+1}}">
                                        <i class="fas fa-angle-right"></i>
                                        <span class="sr-only">Next</span>
                                    </a>
                                </li>
                                @endif
                                </ul>
                            </nav>
                        </div>
                        
                    </div>
                </div>
            </div>
            @include('layouts.footers.auth')
        </div>
        
    </div>

    <!--Delete Modal Notification Section-->
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">GOPA Dashboard</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete this statement data?
            </div>
            <form method="post" id="form_delete">
                @csrf
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-warning">Delete <i class="fas fa-trash"></i></button>
                </div>
            </form>
            </div>
        </div>
    </div>
@endsection

@push('js')
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.extension.js"></script>

    <script>
        $(".triggerDelete").click(function () {
            var id = $(this).data('id');
            $('#deleteModal').modal("show");
            $('#form_delete').attr('action', 'statements/delete/'+id);
        });
    </script>
@endpush