@extends('layouts.app-players')

<title>Add Game ID · GOPA Dashboard</title> 

@section('content')
    @include('users.partials.header-players', [
        'title' => __('To') . ' '. auth()->user()->name,
        'description' => __('On this page you can add Game ID to existing players.'),
        'class' => 'col-lg-9'
    ])   

        <div class="container-fluid mt--8">
            <div class="row">
                <div class="col">
                    <div class="card">

                        <div class="card-header bg-transparent">
                            <div class="row align-items-center">
                                <div class="col">
                                    <h3 class="mb-0"><i class="fas fa-user-plus"></i>&emsp;Add Player Game ID</h3>
                                </div>
                            </div>
                        </div>
                    
                    <!--bagian ini untuk melakukan konfigurasi dengan admin-->
                    <div class="card-body">
                        <form method="post" action="{{ route('createplayer') }}" autocomplete="off">
                            <h6 class="heading-small text-muted mb-4">Add Game ID Player to This Player</h6>
                                <div class="form-group">
                                <div class="pl-lg-4">
                                    @csrf
                                    @method('post')
                                    
                                    @if (session('status'))
                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                            {{ session('status') }}
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                    @endif
                                    @if($errors->any())
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            {{$errors->first()}}
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                    @endif
                                    
                                    <label class="form-control-label" for="input-name">New Game ID for Player: {{$player->nickname1}}/{{$player->marker1}}'</label>
                                    <input type="number" name="telephone" id="input-telephone" class="form-control form-control-alternative" placeholder="{{ __('Enter the relevant Player ID') }}" required autofocus>
                                <div class="text-left mb-4">
                                    <button type="submit" class="btn btn-success mt-4">Add Game ID&emsp;<i class="fas fa-plus"></i></button>
                                </div>
                                </div>


                            </div>
                        </form>
                    </div>
                        
                    </div>
                </div>
            </div>
            @include('layouts.footers.auth')
        </div>
        
    </div>
@endsection

@push('js')
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.extension.js"></script>
@endpush