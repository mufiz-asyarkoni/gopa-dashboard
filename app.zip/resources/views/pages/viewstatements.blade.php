@extends('layouts.app-statements')

@foreach($statement_player as $player)
<title>Desk No {{$player->desk_id}} · GOPA Dashboard</title>
@endforeach

@section('content')
    @include('users.partials.header-statements', [
        'title' => __('Hello') . ' '. auth()->user()->name,
        'description' => __('On this page you can see details of the games played by your players.'),
        'class' => 'col-lg-7'
    ])   
    
        <div class="container-fluid mt--8">
            <div class="row justify-content-center">
                <div class=" col ">
                    <div class="card">
                        
                        <!--Desk Number Header Section-->
                        <div class="card-header bg-transparent">
                            <h3 class="mb-0">Desk No {{$statement_player[0]->desk_id}}</h3>
                        </div>
                        
                        <!--Player Information Section-->
                         <div class="card-body">
                            <h6 class="heading-small text-muted mb-4">Final Score Information</h6>
                            <div class="row players-information">
                                
                                @foreach($statement_player as $player)
                                <div class="col-lg-4 col-md-6">
                                    <a href= "{{ route('viewplayers', ['player' => optional($player->player)->id ? $player->player->id : '#']) }}">
                                    <button  type="button" class="btn-icon-clipboard" data-clipboard-text="active-40"
                                        title="View player details">
                                        <div>
                                            <div class="avatar rounded-circle mr-0">
                                            <img alt="Image placeholder" src="{{optional($player->player)->avatar1}}">
                                            </div>
                                            <span><h5>{{optional($player->player)->nickname1}}</h5>Game ID: {{$player->game_id}}<br/>Score: <i class="fa-solid fa-gem fa-xs"></i>&nbsp;{{$player->game_detail->where('desk_no', $player->desk_id)->first()->score_final}}<br/><small>IP- {{$player->ip}}</small> </span>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                @endforeach
                                
                            </div>
                        </div>
                        
                        <!--Game Desk Information Section-->
                        <div class="card-body">
                            <h6 class="heading-small text-muted mb-4">Game Desk Information</h6>
                            <div class="row players-information">
                                
                            @for($i=1;$i<=$score_total;$i++)
                                
                                <div class="col-lg-6 col-md-6">
                                    <a data-toggle="modal" data-target="#modal-notification">
                                    <button  type="button" class="btn-icon-clipboard" data-round="{{$i}}" data-clipboard-text="active-40"
                                        title="View round details">
                                        <div>
                                            <h3><i class="ni ni-button-play"></i>&nbsp; Round: {{$i}}</h3>
                                        </div>
                                    </button>
                                    </a>
                                </div>

                            @endfor
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
        @include('layouts.footers.auth')
    </div>
    
        <div class="modal fade" id="modal-notification" tabindex="-1" role="dialog" aria-labelledby="modal-notification" ria-hidden="true">
            <div class="modal-dialog modal-danger modal-dialog-centered modal-lg" role="document">
                <div class="modal-content bg-gradient-primary">
                    
                    
                    <div class="modal-header">
                        <h6 class="modal-title" id="modal-title-notification">Round 1: Desk No. &nbsp;{{$statement_player[0]->desk_id}}</h6>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">x</span>
                        </button>
                    </div>
                    
                    
                    <div class="modal-body">
                        <h4 class="text-center heading mt--4 mb-4">Round Details Information</h4>
                        <div class="row players-information">
                            
                            @foreach($game_id as $key => $game)
                                <div class="col-lg-4 col-md-4">
                                    <a href= "{{ route('viewplayers', ['player' => $game->player->id ?? '#']) }}">
                                    <button type="button" class="btn-icon-clipboard" data-clipboard-text="active-40">
                                        <div>
                                            <a id="detail-{{$key+1}}">ID:</a>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                            @endforeach
                            
                        </div>
                    </div>
                    <div class="modal-footer mt--4">
                        <button type="button" class="btn btn-link text-white ml-auto"
                            data-dismiss="modal">Close</button>
                    </div>

                </div>
            </div>
        </div>
    
@endsection

@push('js')
    <script>
        var score = {!! str_replace("'", "\'", json_encode($score)) !!};
        var game_id = {!! str_replace("'", "\'", json_encode($game_id)) !!};
        var desk_id = {{$statement_player[0]->desk_id}};

        $(".btn-icon-clipboard").click(function () {
            var round = $(this).data('round');
            $('#modal-title-notification').html('Round '+round+': Desk No '+desk_id);
            for (let i = 0; i < {{$score_total}}; i++) {
                $('#detail-'+(i+1)).html("ID: "+game_id[i]+" <br/><b>"+score[round][i]+"</b>");
            }
        });
    </script>
@endpush