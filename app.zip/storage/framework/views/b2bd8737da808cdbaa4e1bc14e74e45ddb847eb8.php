
<title>Player <?php echo e($player->game_id1); ?> · GOPA Dashboard</title>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.partials.header-players', [
        'title' => __('Hello') . ' '. auth()->user()->name,
        'description' => __('On this page you can see the details of your players according to your needs.'),
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
    
    <div class="container-fluid mt--8">
        <div class="row">
            <div class="col-xl-4 order-xl-2 mb-4 mb-xl-0">
                <div class="card card-profile shadow">
                    <div class="row justify-content-center">
                        <div class="col-lg-3 order-lg-2 mt-4">
                            <div class="card-profile-image">
                                <a href="#">
                                    <img src="<?php echo e($player->avatar1); ?>" class="rounded-circle">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="card-body pt-0 pt-md-1">
                        <div class="row">
                            <div class="col">
                                <div class="card-profile-stats d-flex justify-content-center mt-md-5">
                                    <div class="text-center">

                                        <h3>
                                            <span class="font-weight-light"></span>
                                        </h3>
            
                                        <hr class="my-4" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-8 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h3 class="mb-0">&emsp;<i class="fas fa-user-tag"></i>&emsp;Player Profile</h3>
                                <div class="col-xl-8 col-3 text-right">
                                    <a href="<?php echo e(route('editplayers', ['player' => $player->id])); ?>" class="btn btn-sm btn-primary" >Edit Player&emsp;<span class="btn-inner--icon"><i class="ni ni-settings"></i></a>
                                </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('profile.update')); ?>" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>

                            <h6 class="heading-small text-muted mb-4"><?php echo e(__('Player information')); ?></h6>
                            
                            <div class="pl-lg-4">
                                <div class="form-group">
                                    <label class="form-control-label">Game ID</label>
                                    <h1 class="display-3"><?php echo e($player->game_id1); ?></h1>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Nickname</label>
                                    <h1 class="display-3"><?php echo e($player->nickname1); ?></h1>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Marker</label>
                                    <h1 class="display-3"><?php echo e($player->marker1); ?></h1>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Player Notes</label>
                                    <?php if($player->notes1 != null): ?>
                                    <h1 class="display-3"><?php echo e($player->notes1); ?></h1>
                                    <?php endif; ?>
                                    <?php if($player->notes1 == null): ?>
                                    <h1 class="display-3">-</h1>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Desks </label>
                                    <small>[<?php echo e(today()->day); ?>-<?php echo e(today()->month); ?>-<?php echo e(today()->year); ?>]</small>
                                    <h1 class="display-3"><?php echo e($desk_today); ?></h1>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Score </label>
                                    <small>[<?php echo e(today()->day); ?>-<?php echo e(today()->month); ?>-<?php echo e(today()->year); ?>]</small>
                                    <h1 class="display-3"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;<?php echo e($score_today); ?></h1>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Total Desks </label>
                                    <h1 class="display-3"><?php echo e($player->desks1); ?></h1>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label">Total Score </label>
                                    <h1 class="display-3"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;<?php echo e($player->score1); ?></h1>
                                </div>

                                <div class="text-center">
                                </div>
                            </div>
                        </form>
                    
                    </div>
                </div>
            </div>
        </div>
        
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-players', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/koonekne/gopa.koonek.net/resources/views/pages/viewplayers.blade.php ENDPATH**/ ?>