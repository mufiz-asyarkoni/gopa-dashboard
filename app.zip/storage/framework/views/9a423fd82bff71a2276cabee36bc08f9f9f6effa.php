<div class="header pb-8 pt-5 pt-lg-8 d-flex align-items-center" style="background-image: url(https://www.slotsformoney.com/wp-content/uploads/2020/09/casino-table-games.jpg); background-size: cover; background-position: center top;">
    <!-- Mask -->
    <span class="mask bg-gradient-default opacity-8"></span>
    <!-- Header container -->
    <div class="container-fluid d-flex align-items-center">
        <div class="row">
            <div class="col-md-3 mt-xl-2 mb-3 mt-3 text-center text-xl-left"><img src="<?php echo e(asset('gopa')); ?>/zhuo_wangpai_l.png" height="130" width="293"></div>
            <div class="col-md-5 ml-xl-6">
                <h1 class="display-2 text-white text-center text-xl-left"><?php echo e($title); ?></h1>
                <?php if(isset($description) && $description): ?>
                    <p class="text-white text-center text-xl-left mt-0 mb-5 pl-3 pr-3 pl-xl-0 pr-xl-0"><?php echo e($description); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div> <?php /**PATH /home/koonekne/gopa.koonek.net/resources/views/users/partials/header-statements.blade.php ENDPATH**/ ?>