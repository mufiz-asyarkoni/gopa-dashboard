

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.partials.header-configuration', [
        'title' => __('Hello') . ' '. auth()->user()->name,
        'description' => __('This is a page for configuring or setting up any data that you will process in the database of this website.'),
        'class' => 'col-lg-7 pr-5 pl-5 pr-xl-3 pl-xl-3'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
    
    <div class="container-fluid mt--8">
        <div class="row">
            
            <div class="col-xl-6 order-xl-1 mb-5">
                <div class="card bg-secondary shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h3 class="mb-0">&emsp;<i class="fas fa-door-open"></i>&emsp;Room Configuration</h3>
                        </div>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('profile.update')); ?>" autocomplete="off">
                            <div class="pl-xl-3 pr-xl-3">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-room">Room ID</label>
                                    <input type="number" name="room" id="input-room" class="form-control form-control-alternative" placeholder="Enter the game room id you want" value="<?php echo e($room->room_id); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label" for="input-rid">Room RID<small> encrypted</small></label>
                                    <input type="password" name="rid" id="input-rid" class="form-control form-control-alternative" placeholder="Ask the website admin" value="<?php echo e($room->room_rid); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label" for="input-sign">Room Sign<small> encrypted</small></label>
                                    <input type="password" name="sign" id="input-sign" class="form-control form-control-alternative" placeholder="Ask the website admin" value="<?php echo e($room->room_sign); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label" for="input-adminid">Your Game ID</label>
                                    <input type="number" name="adminid" id="input-adminid" class="form-control form-control-alternative" placeholder="Enter your game id as admin" value="<?php echo e($room->admin_game_id); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label" for="input-telephone">Your Telephone</label>
                                    <input type="number" name="rid" id="input-telephone" class="form-control form-control-alternative" placeholder="Enter your telephone number as admin" value="<?php echo e($room->admin_telephone); ?>" required>
                                </div>                                
                                <div class="form-group">
                                    <label class="form-control-label" for="input-username">Username<small> encrypted</small></label>
                                    <input type="password" name="username" id="input-username" class="form-control form-control-alternative" placeholder="Ask the website admin" value="<?php echo e($room->admin_username); ?>" required>
                                </div>

                                <div class="text-left mb-3">
                                    <button type="submit" class="btn btn-success mt-4">Create Room <i class="fas fa-database"></i></button>
                                </div>
                            </div>
                        </form>
                        <hr class="my-4" />
                        <div class="row pl-xl-3 pr-xl-3 pl-3 pr-3">
                                <div class="col-xl-4 col-lg-4 pl-3 pr-3">
                                    <label class="form-control-label">Total Room</label>
                                    <h2 class="display-3">1</h2>
                                </div>
                                <div class="col-xl-4 col-lg-4 pl-3 pr-3">
                                    <label class="form-control-label">Room Existing</label>
                                    <button type="button" class="btn btn-success btn-sm">10010629</button>
                                </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-xl-6 order-xl-1">
                <div class="card bg-secondary shadow">
                    <div class="card-header bg-white border-0">
                        <div class="row align-items-center">
                            <h3 class="mb-0">&emsp;<i class="fas fa-chart-pie"></i>&emsp;Admin Fee Configuration</h3>
                        </div>
                    </div>
                    <div class="card-body">
                        
                        <form method="post" action="<?php echo e(route('configuration.update', ['fee_admin' => $fee_admin[0]->id])); ?>" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <?php $__currentLoopData = $fee_admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php if(session('status')): ?>
                                <div class="alert alert-info alert-dismissible fade show" role="alert">
                                    <?php echo e(session('status')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                            <div class="pl-xl-3 pr-xl-3">
                                <div class="form-group">
                                    <label class="form-control-label" for="input-fee">Player Position 1</label>
                                    <input type="number" name="fee_admin1" id="input-fee-1" class="form-control form-control-alternative" placeholder="Enter the admin fee for the first order player" value="<?php echo e($fee->fee_admin1); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label" for="input-fee">Player Position 2</label>
                                    <input type="number" name="fee_admin2" id="input-fee-2" class="form-control form-control-alternative" placeholder="Enter the admin fee for the second order player" value="<?php echo e($fee->fee_admin2); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label" for="input-fee">Player Position 3</label>
                                    <input type="number" name="fee_admin3" id="input-fee-2" class="form-control form-control-alternative" placeholder="Enter the admin fee for the third order player" value="<?php echo e($fee->fee_admin3); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label" for="input-fee">Player Position 4</label>
                                    <input type="number" name="fee_admin4" id="input-fee-2" class="form-control form-control-alternative" placeholder="Enter the admin fee for the fourth player" value="<?php echo e($fee->fee_admin4); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label" for="input-fee">Player Position 5</label>
                                    <input type="number" name="fee_admin5" id="input-fee-2" class="form-control form-control-alternative" placeholder="Enter the admin fee for the fifth player" value="<?php echo e($fee->fee_admin5); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label" for="input-fee">Player Position 6</label>
                                    <input type="number" name="fee_admin6" id="input-fee-2" class="form-control form-control-alternative" placeholder="Enter the admin fee for the sixth player" value="<?php echo e($fee->fee_admin6); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label" for="input-fee">Player Position 7</label>
                                    <input type="number" name="fee_admin7" id="input-fee-2" class="form-control form-control-alternative" placeholder="Enter the admin fee for the seventh order player" value="<?php echo e($fee->fee_admin7); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label" for="input-fee">Player Position 8</label>
                                    <input type="number" name="fee_admin8" id="input-fee-2" class="form-control form-control-alternative" placeholder="Enter the admin fee for the eighth order player" value="<?php echo e($fee->fee_admin8); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-control-label" for="input-fee">Player Position 9</label>
                                    <input type="number" name="fee_admin9" id="input-fee-2" class="form-control form-control-alternative" placeholder="Enter the admin fee for the ninth order player" value="<?php echo e($fee->fee_admin9); ?>" required>
                                </div>                                
                                <div class="text-left mb-3">
                                    <button type="submit" class="btn btn-success mt-4">Save Fee Admin <i class="fas fa-dollar-sign"></i></button>
                                </div>
                            </div>
                            
                        </form>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
            </div>
        </div>
        
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app-configuration', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/koonekne/gopa.koonek.net/resources/views/pages/configuration.blade.php ENDPATH**/ ?>