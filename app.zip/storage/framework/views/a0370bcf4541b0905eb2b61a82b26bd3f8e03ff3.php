

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('users.partials.header-grouping', [
'title' => __('To') . ' '. auth()->user()->name,
'description' => __('On this page you can group the players you manage in the website database.'),
'class' => 'col-lg-7 pr-5 pl-5 pr-xl-3 pl-xl-3'
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid mt--8">
    <div class="row">
        <div class="col">
            <div class="card bg-white shadow pl-xl-4 pr-xl-4 pl-3 pr-3">
                <form method="get">
                    <div class="card-header bg-transparent">

                        <div class="row align-items-center">
                            <h6 class="heading-small text-muted mb-4">Player Filtering</h6>
                        </div>

                        <div class="row align-items-center">
                            <div class="input-group mb-4">
                                <select class="form-control" name="group">
                                    <option value="">Grouping Select</option>
                                    <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groups): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($groups->id); ?>"><i class="ni ni-circle-08"></i><?php echo e($groups->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="row align-items-center">
                            <div class="input-group mb-3">
                                <input type="text" name="search" class="form-control" value="<?php echo e(request('search')); ?>" placeholder="Nickname/Marker/Game ID" aria-label="Nickname/Marker/Game ID" aria-describedby="button-addon2">
                                <div class="input-group-append">
                                    <button class="btn btn-outline-primary" type="submit" id="button-addon2"><span class="btn-inner--icon"><i class="ni ni-send"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>

<form action="addgrouping" method="post" id="group-control">
    <?php echo csrf_field(); ?>
    <div class="container-fluid mt-3">
        <div class="row">
            <div class="col">
                <div class="card bg-white shadow">
                            <?php if(session('status')): ?>
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    <i class="fas fa-exclamation"></i>&nbsp;&nbsp;<?php echo e(session('status')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col-xl-4 col-5">
                                <h3 class="mb-0">Player Group Table</h3>
                            </div>
                            <div class="col-xl-8 col-5 text-right text-xl-right ">
                                <button type="button" data-toggle="modal" data-target="#deleteModal1" data-control="rmfgroup" class="btn btn-sm btn-danger btn-control mb-2 mb-xl-0">Remove From Group <span class="btn-inner--icon"><i class="ni ni-fat-remove"></i></button>
                                <button type="button" data-toggle="modal" data-target="#deleteModal2" data-control="rmgroup" class="btn btn-sm btn-danger btn-control mb-2 mb-xl-0">Delete Group <span class="btn-inner--icon"><i class="ni ni-fat-remove"></i></button>
                                <button type="button" data-toggle="modal" data-target="#modal-form2" data-control="addtgroup" class="btn btn-sm btn-primary btn-control mb-2 mb-xl-0">Add Player to Group <span class="btn-inner--icon"><i class="ni ni-single-copy-04"></i></button>
                                <button type="button" data-toggle="modal" data-target="#modal-form1" data-control="addgroup" class="btn btn-sm btn-primary btn-control">Add Group <span class="btn-inner--icon"><i class="ni ni-circle-08"></i></button>
                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" class="sort" data-sort="name"><input type="checkbox" id="select-all" aria-label="Checkbox for following text input"></th>
                                    <th scope="col" class="sort" data-sort="name">No.</th>
                                    <th scope="col" class="sort" data-sort="avatar">Avatar</th>
                                    <th scope="col" class="sort" data-sort="nickname">Nickname</th>
                                    <th scope="col" class="sort" data-sort="marker">Marker</th>
                                    <th scope="col" class="sort" data-sort="user_id">Game ID</th>
                                </tr>
                            </thead>

                            <tbody class="list">
                                <?php
                                $index = 1;
                                $page = request('page') ?? 1;
                                ?>



                                <?php if($group_player): ?>
                                <?php $__currentLoopData = $group_player; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <input type="checkbox" name="selected[]" value="<?php echo e($player->player->game_id1); ?>" aria-label="Checkbox for following text input">
                                    </td>
                                    <th>
                                        <button type="button" class="btn btn-secondary btn-sm"><?php if($page != 1): ?> <?php echo e((($page-1)*15)+$index); ?> <?php else: ?> <?php echo e($index); ?> <?php endif; ?></button>
                                    </th>
                                    <td class="media align-items-center">
                                        <a href="viewplayers/<?php echo e($player->player->id); ?>" class="avatar rounded-circle mr-3">
                                            <img alt="Image placeholder" src="<?php echo e($player->player->avatar1); ?>">
                                        </a>
                                    </td>
                                    <td>
                                        <?php echo e($player->player->nickname1); ?>

                                    </td>
                                    <td>
                                        <?php echo e($player->player->marker1); ?>

                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-success btn-sm" href="<?php echo e(route('viewplayers', ['player' => $player->id])); ?>"><?php echo e($player->player->game_id1); ?></button>
                                    </td>
                                </tr>
                                <?php
                                $index++;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <?php $__currentLoopData = $players2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $players): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(count($players) > 1): ?>
                                <tr>
                                    <td>
                                        <input type="checkbox" name="selected[]" value="<?php echo e($players[0]->game_id1); ?>" aria-label="Checkbox for following text input">
                                    </td>
                                    <th>
                                        <button type="button" class="btn btn-secondary btn-sm"><?php if($page != 1): ?> <?php echo e((($page-1)*15)+$index); ?> <?php else: ?> <?php echo e($index); ?> <?php endif; ?></button>
                                    </th>
                                    <td class="media align-items-center">
                                        <a href="viewplayers/<?php echo e($player->id); ?>" class="avatar rounded-circle mr-3">
                                            <img alt="Image placeholder" src="<?php echo e($players[0]->avatar1); ?>">
                                        </a>
                                    </td>
                                    <td>
                                        <?php echo e($players[0]->nickname1); ?>

                                    </td>
                                    <td>
                                        <?php echo e($players[0]->marker1); ?>

                                    </td>
                                    <td>
                                        <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <button type="button" class="btn btn-success btn-sm" href="<?php echo e(route('viewplayers', ['player' => $player->id])); ?>"><?php echo e($player->game_id1); ?></button>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                </tr>
                                <?php else: ?>
                                <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <input type="checkbox" name="selected[]" value="<?php echo e($player->game_id1); ?>" aria-label="Checkbox for following text input">
                                    </td>
                                    <th>
                                        <button type="button" class="btn btn-secondary btn-sm"><?php if($page != 1): ?> <?php echo e((($page-1)*15)+$index); ?> <?php else: ?> <?php echo e($index); ?> <?php endif; ?></button>
                                    </th>
                                    <td class="media align-items-center">
                                        <a href="viewplayers/<?php echo e($player->id); ?>" class="avatar rounded-circle mr-3">
                                            <img alt="Image placeholder" src="<?php echo e($player->avatar1); ?>">
                                        </a>
                                    </td>
                                    <td>
                                        <?php echo e($player->nickname1); ?>

                                    </td>
                                    <td>
                                        <?php echo e($player->marker1); ?>

                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-success btn-sm" href="<?php echo e(route('viewplayers', ['player' => $player->id])); ?>"><?php echo e($player->game_id1); ?></button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                <?php
                                $index++;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <!--Pagination Section-->
                    <div class="card-footer py-4">
                        <nav aria-label="...">
                            <ul class="pagination justify-content-end mb-0">

                            <?php if($page != 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo e($page-1); ?>" tabindex="-1">
                                        <i class="fas fa-angle-left"></i>
                                        <span class="sr-only">Previous</span>
                                    </a>
                                </li>
                                <?php endif; ?>
                                
                                <?php
                                    $init = 1;
                                    $continues = 1;

                                    if($total_page == 1 || $total_page <= 3 && $page <= 3){
                                        $init = 1;
                                        $continues = $total_page;
                                    }elseif($total_page > 3 && $page <= 3){
                                        $init = 1;
                                        $continues = 3;
                                    }elseif($page == $total_page){
                                        $init = $page-3;
                                        $continues = $page-1;
                                    }else{
                                        $init = $page-2;
                                        $continues = $page;
                                    }
                                ?>

                                <?php for($i=$init;$i<=$continues;$i++): ?>
                                <li class="page-item <?php if($page == $i): ?> active <?php endif; ?>">
                                    <a class="page-link" href="?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                                </li>
                                <?php endfor; ?>

                                <?php if($total_page>4): ?>
                                <li class="page-item <?php if($page == $total_page): ?> active <?php endif; ?>">
                                    <a class="page-link" href="?page=<?php echo e($total_page); ?>"><?php echo e($total_page); ?></a>
                                </li>
                                <?php endif; ?>
                                
                                <?php if($page != $total_page): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo e($page+1); ?>">
                                        <i class="fas fa-angle-right"></i>
                                        <span class="sr-only">Next</span>
                                    </a>
                                </li>
                                <?php endif; ?>
                                
                            </ul>
                        </nav>
                    </div>

                </div>
            </div>
        </div>


        <!--Modal untuk menampilkan pilihan grup-->
        <div class="modal fade" id="modal-form2" tabindex="-1" role="dialog" aria-labelledby="modal-form1" aria-hidden="true">
            <div class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel">GOPA Dashboard</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body p-0">
                        <div class="card-body px-lg-5 py-lg-1">
                            <div class="text-center text-muted mb-4">
                                <h3>Select group for selected players</h3>
                            </div>
                            <div class="form-group mb-3">
                                <div class="input-group mb-4">
                                    <select class="form-control" name="group_selection">
                                        <option>Grouping Select</option>
                                        <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groups): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($groups->id); ?>"><i class="ni ni-circle-08"></i><?php echo e($groups->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-info mb-5 mt-3">Select Group <i class="fas fa-users"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!--Modal untuk menampilkan tambah grup-->
        <div class="modal fade" id="modal-form1" tabindex="-1" role="dialog" aria-labelledby="modal-form1" aria-hidden="true">
            <div class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel">GOPA Dashboard</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body p-0">
                        <div class="card-body px-lg-5 py-lg-1">
                            <div class="text-center text-muted mb-4">
                                <h3>Create a new player group</h3>
                            </div>
                            <div class="form-group mb-3">
                                <div class="input-group input-group-alternative">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="ni ni-circle-08"></i></span>
                                    </div>
                                    <input class="form-control" name="group_name" placeholder="Group name" type="text">
                                </div>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-success mb-5 mt-3">Create Group <i class="fas fa-plus"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--Modal untuk menghapus grup yang sudah ada-->
        <div class="modal fade" id="deleteModal2" tabindex="-1" role="dialog" aria-labelledby="modal-form1" aria-hidden="true">
            <div class="modal-dialog modal- modal-dialog-centered modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel">GOPA Dashboard</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body p-0">
                        <div class="card-body px-lg-5 py-lg-1">
                            <div class="text-center text-muted mb-4">
                                <h3>Select the group to delete</h3>
                            </div>
                            <div class="form-group mb-3">
                                <div class="input-group mb-4">
                                    <select class="form-control" name="group">
                                        <option>Grouping Select</option>
                                        <?php $__currentLoopData = $group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groups): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($groups->id); ?>"><i class="ni ni-circle-08"></i><?php echo e($groups->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
 
                            <div class="text-center">
                                <button type="submit" class="btn btn-warning mb-5 mt-3">Delete Group <i class="fas fa-trash"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--Modal untuk mengeluarkan player dari grup-->
        <div class="modal fade" id="deleteModal1" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="deleteModalLabel">GOPA Dashboard</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <div class="modal-body">
                        Are you sure you want to remove this player from group?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close </button>
                        <button type="submit" class="btn btn-warning">Remove <i class="fas fa-trash"></i></button>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</form>





<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.min.js"></script>
<script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.extension.js"></script>

<script>
    var check = true;
    $('#select-all').click(function(event) {
        check = !check;
        $(':checkbox').each(function() {
            this.checked = !check;
        });
    });

    var link = [];
    link['rmfgroup'] = 'removegrouping';
    link['rmgroup'] = 'dropgrouping';
    link['addtgroup'] = 'addgrouping';
    link['addgroup'] = 'storegrouping';

    $('.btn-control').click(function(event) {
        var data = $(this).data('control');
        $('#group-control').attr('action', link[data]);
    });
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app-grouping', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/koonekne/gopa.koonek.net/resources/views/pages/grouping.blade.php ENDPATH**/ ?>