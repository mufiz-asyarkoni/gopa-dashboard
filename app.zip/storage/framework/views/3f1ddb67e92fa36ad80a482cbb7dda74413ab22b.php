

<title>Add Game ID · GOPA Dashboard</title> 

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.partials.header-players', [
        'title' => __('To') . ' '. auth()->user()->name,
        'description' => __('On this page you can add Game ID to existing players.'),
        'class' => 'col-lg-9'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

        <div class="container-fluid mt--8">
            <div class="row">
                <div class="col">
                    <div class="card">

                        <div class="card-header bg-transparent">
                            <div class="row align-items-center">
                                <div class="col">
                                    <h3 class="mb-0"><i class="fas fa-user-plus"></i>&emsp;Add Player Game ID</h3>
                                </div>
                            </div>
                        </div>
                    
                    <!--bagian ini untuk melakukan konfigurasi dengan admin-->
                    <div class="card-body">
                        <form method="post" action="<?php echo e(route('createplayer')); ?>" autocomplete="off">
                            <h6 class="heading-small text-muted mb-4">Add Game ID Player to This Player</h6>
                                <div class="form-group">
                                <div class="pl-lg-4">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('post'); ?>
                                    
                                    <?php if(session('status')): ?>
                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                            <?php echo e(session('status')); ?>

                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                    <?php if($errors->any()): ?>
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <?php echo e($errors->first()); ?>

                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <label class="form-control-label" for="input-name">New Game ID for Player: <?php echo e($player->nickname1); ?>/<?php echo e($player->marker1); ?>'</label>
                                    <input type="number" name="telephone" id="input-telephone" class="form-control form-control-alternative" placeholder="<?php echo e(__('Enter the relevant Player ID')); ?>" required autofocus>
                                <div class="text-left mb-4">
                                    <button type="submit" class="btn btn-success mt-4">Add Game ID&emsp;<i class="fas fa-plus"></i></button>
                                </div>
                                </div>


                            </div>
                        </form>
                    </div>
                        
                    </div>
                </div>
            </div>
            <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.extension.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app-players', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/koonekne/gopa.koonek.net/resources/views/pages/gameid.blade.php ENDPATH**/ ?>