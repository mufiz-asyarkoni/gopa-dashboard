

<?php $__currentLoopData = $statement_player; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<title>Desk No <?php echo e($player->desk_id); ?> · GOPA Dashboard</title>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.partials.header-statements', [
        'title' => __('Hello') . ' '. auth()->user()->name,
        'description' => __('On this page you can see details of the games played by your players.'),
        'class' => 'col-lg-7'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
    
        <div class="container-fluid mt--8">
            <div class="row justify-content-center">
                <div class=" col ">
                    <div class="card">
                        
                        <!--Desk Number Header Section-->
                        <div class="card-header bg-transparent">
                            <h3 class="mb-0">Desk No <?php echo e($statement_player[0]->desk_id); ?></h3>
                        </div>
                        
                        <!--Player Information Section-->
                         <div class="card-body">
                            <h6 class="heading-small text-muted mb-4">Final Score Information</h6>
                            <div class="row players-information">
                                
                                <?php $__currentLoopData = $statement_player; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 col-md-6">
                                    <a href= "<?php echo e(route('viewplayers', ['player' => optional($player->player)->id ? $player->player->id : '#'])); ?>">
                                    <button  type="button" class="btn-icon-clipboard" data-clipboard-text="active-40"
                                        title="View player details">
                                        <div>
                                            <div class="avatar rounded-circle mr-0">
                                            <img alt="Image placeholder" src="<?php echo e(optional($player->player)->avatar1); ?>">
                                            </div>
                                            <span><h5><?php echo e(optional($player->player)->nickname1); ?></h5>Game ID: <?php echo e($player->game_id); ?><br/>Score: <i class="fa-solid fa-gem fa-xs"></i>&nbsp;<?php echo e($player->game_detail->where('desk_no', $player->desk_id)->first()->score_final); ?><br/><small>IP- <?php echo e($player->ip); ?></small> </span>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </div>
                        </div>
                        
                        <!--Game Desk Information Section-->
                        <div class="card-body">
                            <h6 class="heading-small text-muted mb-4">Game Desk Information</h6>
                            <div class="row players-information">
                                
                            <?php for($i=1;$i<=$score_total;$i++): ?>
                                
                                <div class="col-lg-6 col-md-6">
                                    <a data-toggle="modal" data-target="#modal-notification">
                                    <button  type="button" class="btn-icon-clipboard" data-round="<?php echo e($i); ?>" data-clipboard-text="active-40"
                                        title="View round details">
                                        <div>
                                            <h3><i class="ni ni-button-play"></i>&nbsp; Round: <?php echo e($i); ?></h3>
                                        </div>
                                    </button>
                                    </a>
                                </div>

                            <?php endfor; ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    
        <div class="modal fade" id="modal-notification" tabindex="-1" role="dialog" aria-labelledby="modal-notification" ria-hidden="true">
            <div class="modal-dialog modal-danger modal-dialog-centered modal-lg" role="document">
                <div class="modal-content bg-gradient-primary">
                    
                    
                    <div class="modal-header">
                        <h6 class="modal-title" id="modal-title-notification">Round 1: Desk No. &nbsp;<?php echo e($statement_player[0]->desk_id); ?></h6>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">x</span>
                        </button>
                    </div>
                    
                    
                    <div class="modal-body">
                        <h4 class="text-center heading mt--4 mb-4">Round Details Information</h4>
                        <div class="row players-information">
                            
                            <?php $__currentLoopData = $game_id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-4 col-md-4">
                                    <a href= "<?php echo e(route('viewplayers', ['player' => $game->player->id ?? '#'])); ?>">
                                    <button type="button" class="btn-icon-clipboard" data-clipboard-text="active-40">
                                        <div>
                                            <a id="detail-<?php echo e($key+1); ?>">ID:</a>
                                        </div>
                                    </button>
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                    </div>
                    <div class="modal-footer mt--4">
                        <button type="button" class="btn btn-link text-white ml-auto"
                            data-dismiss="modal">Close</button>
                    </div>

                </div>
            </div>
        </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        var score = <?php echo str_replace("'", "\'", json_encode($score)); ?>;
        var game_id = <?php echo str_replace("'", "\'", json_encode($game_id)); ?>;
        var desk_id = <?php echo e($statement_player[0]->desk_id); ?>;

        $(".btn-icon-clipboard").click(function () {
            var round = $(this).data('round');
            $('#modal-title-notification').html('Round '+round+': Desk No '+desk_id);
            for (let i = 0; i < <?php echo e($score_total); ?>; i++) {
                $('#detail-'+(i+1)).html("ID: "+game_id[i]+" <br/><b>"+score[round][i]+"</b>");
            }
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app-statements', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/koonekne/gopa.koonek.net/resources/views/pages/viewstatements.blade.php ENDPATH**/ ?>