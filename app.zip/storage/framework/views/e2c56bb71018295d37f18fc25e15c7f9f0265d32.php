<div class="header bg-gradient-primary pb-7 pt-5 pt-md-8 mb-xl-4">
    <div class="container-fluid">
        <div class="header-body">
            <!-- Statistik Pengolahan -->
            <div class="row">
                <div class="col-xl-4 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Total Desks</h5>
                                    <span class="h2 font-weight-bold mb-0"><?php echo e($total_desks); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-danger text-white rounded-circle shadow">
                                        <a class="nav-link text-white" href="<?php echo e(route('statements')); ?>">
                                        <i class="fas fa-couch"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Total Players <small>(id)</small></h5>
                                    <span class="h2 font-weight-bold mb-0"><?php echo e($total_player); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-green text-white rounded-circle shadow">
                                        <a class="nav-link text-white" href="<?php echo e(route('players')); ?>">                                        
                                        <i class="fas fa-users"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Total Room</h5>
                                    <span class="h2 font-weight-bold mb-0"><?php echo e($total_room); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-orange text-white rounded-circle shadow">
                                        <a class="nav-link text-white" href="<?php echo e(route('configuration')); ?>">
                                        <i class="fas fa-door-open"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="header bg-gradient-primary pb-8 pt-0 pt-md-0 mt--7">
    <div class="container-fluid">
        <div class="header-body">
            <!-- Card stats -->
            <div class="row">
                <div class="col-xl-4 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Total Group</h5>
                                    <span class="h2 font-weight-bold mb-0"><?php echo e($total_group); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-primary text-white rounded-circle shadow">
                                        <a class="nav-link text-white" href="<?php echo e(route('grouping')); ?>">
                                        <i class="fas fa-warehouse"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Today Admin Fee</h5>
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;<?php echo e($total_today_fee); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-pink text-white rounded-circle shadow">
                                        <a class="nav-link text-white" href="<?php echo e(route('gamedetails')); ?>">
                                        <i class="fas fa-chart-pie"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Update</h5>
                                    <span class="h2 font-weight-bold mb-0"><?php echo date("d-m-Y"); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-info text-white rounded-circle shadow">
                                        <i class="fas fa-calendar"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH /home/koonekne/gopa.koonek.net/resources/views/layouts/headers/cards.blade.php ENDPATH**/ ?>