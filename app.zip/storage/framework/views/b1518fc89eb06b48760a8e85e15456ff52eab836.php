<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
    <div class="container-fluid">
        <!-- Toggler -->
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Brand -->
        <a class="navbar-brand pt-0" href="<?php echo e(route('home')); ?>">
            <img src="/public/argon/img/brand/blue2.png" class="navbar-brand-img" alt="...">
        </a>
        <!-- User -->
        <ul class="nav align-items-center d-md-none">
            <li class="nav-item dropdown">
                <a class="nav-link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <div class="media align-items-center">
                        <span class="avatar avatar-sm rounded-circle">
                        <img alt="Image placeholder" src="https://thirdwx.qlogo.cn/mmopen/vi_32/u5GVX0bXHRFzb0Hnb9B2vM871HnbL7bPskKcqWq2RicBCU2K3kYN3N6I9VJ1QQXvkMSdZqWDonhENtAia7qVzJWw/132">
                        </span>
                    </div>
                </a>
                <div class="dropdown-menu dropdown-menu-arrow dropdown-menu-right">
                    <div class=" dropdown-header noti-title">
                        <h6 class="text-overflow m-0"><?php echo e(__('Welcome -')); ?>&nbsp;<?php echo e(auth()->user()->name); ?></h6>
                    </div>
                    <a href="<?php echo e(route('profile.edit')); ?>" class="dropdown-item">
                        <i class="ni ni-single-02"></i>
                        <span><?php echo e(__('My profile')); ?></span>
                    </a>
                    <a href="mailto:admin@gopa.koonek.net" class="dropdown-item">
                        <i class="ni ni-email-83"></i>
                        <span><?php echo e(__('Support')); ?></span>
                    </a>
                    <div class="dropdown-divider"></div>
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                        <i class="ni ni-user-run"></i>
                        <span><?php echo e(__('Logout')); ?></span>
                    </a>
                </div>
            </li>
        </ul>
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
            <!-- Collapse header -->
            <div class="navbar-collapse-header d-md-none">
                <div class="row">
                    <div class="col-6 collapse-brand">
                        <a href="<?php echo e(route('home')); ?>">
                            <img src="<?php echo e(asset('argon')); ?>/img/brand/blue2.png">
                        </a>
                    </div>
                    <div class="col-6 collapse-close">
                        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#sidenav-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                </div>
            </div>
            <!-- Form -->
            <form class="mt-4 mb-3 d-md-none">
                <div class="input-group input-group-rounded input-group-merge">
                    <div class="form-group mb-0">
                        <a>exp: 25 August 2022</a>
                    </div>
                </div>
            </form>
            <!-- Navigation -->
            <ul class="navbar-nav">
                <li class="nav-item ">
                    <a class="nav-link" href="<?php echo e(route('home')); ?>">
                        <i class="ni ni-tv-2 text-primary"></i>Home
                    </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link " href="<?php echo e(route('statements')); ?>">
                        <i class="ni ni-bullet-list-67 text-primary"></i> <?php echo e(__('Statements')); ?>

                    </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link " href="<?php echo e(route('players')); ?>">
                        <i class="ni ni-single-02 text-green"></i> <?php echo e(__('Players')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('grouping')); ?>">
                        <i class="ni ni-circle-08 text-green"></i> <?php echo e(__('Grouping')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('blacklist')); ?>">
                        <i class="ni ni-badge text-green"></i>Blacklist <small>&nbsp;&nbsp;[coming soon]</small>
                    </a>
                </li>   
                <li class="nav-item active">
                    <a class="nav-link active" href="<?php echo e(route('history')); ?>">
                        <i class="ni ni-archive-2 text-orange"></i> <?php echo e(__('History')); ?>

                    </a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" href="<?php echo e(route('gamedetails')); ?>">
                        <i class="ni ni-controller text-orange"></i> <?php echo e(__('Game Details')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('score-utilization')); ?>">
                      <i class="ni ni-money-coins text-default"></i> <?php echo e(__('Score Utilization')); ?>

                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('configuration')); ?>">
                      <i class="ni ni-settings-gear-65 text-default"></i> <?php echo e(__('Configuration')); ?>

                    </a>
                </li>
            </ul>

        </div>
    </div>
</nav>
<?php /**PATH /home/koonekne/gopa.koonek.net/resources/views/layouts/navbars/sidebar-history.blade.php ENDPATH**/ ?>