<div class="header pb-8 pt-5 pt-lg-8 d-flex align-items-center" style="background-image: url(https://newtheory.com/wp-content/uploads/2022/04/pexels-aidan-howe-4677402.jpg); background-size: cover; background-position: center top;">
    <!-- Mask -->
    <span class="mask bg-gradient-default opacity-8"></span>
    <!-- Header container -->
    <div class="container-fluid d-flex align-items-center">
        <div class="row">
            <div class="col-md-3 mt-xl-2 mb-3 mt-3 text-center text-xl-left"><img src="<?php echo e(asset('gopa')); ?>/zuanshi5.png" height="121" width="146"></div>
            <div class="col-md-6 ml-xl--5">
                <h1 class="display-2 text-white text-center text-xl-left"><?php echo e($title); ?></h1>
                <?php if(isset($description) && $description): ?>
                    <p class="text-white text-center text-xl-left mt-0 mb-5 pl-3 pr-3 pl-xl-0 pr-xl-0"><?php echo e($description); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div> <?php /**PATH /home/koonekne/gopa.koonek.net/resources/views/users/partials/header-score-utilization.blade.php ENDPATH**/ ?>