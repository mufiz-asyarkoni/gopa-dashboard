

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('users.partials.header-score-utilization', [
        'title' => __('To') . ' '. auth()->user()->name,
        'description' => __('On this page you can see the history of changes in the score or credit of each player from time to time.'),
        'class' => 'col-lg-7 pr-5 pl-5 pr-xl-3 pl-xl-3'
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   

        <form>
            <div class="container-fluid mt--8">
            <div class="row">
                <div class="col">
                    <div class="card bg-white shadow pl-xl-4 pr-xl-4 pl-3 pr-3">
                        <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                                <h6 class="heading-small text-muted mb-4">Player Filtering</h6>
                            </div>
                        <div class="row align-items-center">
                                <div class="input-group mb-3">
                                  <input type="text" class="form-control" placeholder="Nickname/Marker/Game ID" name="search" value="<?php echo e(request('search') ?? ''); ?>" aria-label="Nickname/Marker/Game ID" aria-describedby="button-addon2">
                                  <div class="input-group-append">
                                    <button class="btn btn-outline-primary" type="submit" id="button-addon2"><span class="btn-inner--icon"><i class="ni ni-send"></i></button>
                                  </div>
                                </div>
                            </div>
                        </div>
                    
                    </div>
                </div>
            </div>
            </div>
        </form>

        <div class="container-fluid mt-3">
            <div class="row">
                <div class="col">
                    <div class="card bg-white shadow">

                        <div class="card-header bg-transparent">
                            <div class="row align-items-center">
                                <div class="col-10">
                                    <h3 class="mb-0">Table of Changes in Score/Credits from Players</h3>
                                </div>
                            </div>
                        </div>
                
                        <div class="table-responsive">
                            <table class="table align-items-center table-flush">
                                <thead class="thead-light">
                                    <tr>
                                        <th scope="col" class="sort" data-sort="name">No.</th>
                                        <th scope="col" class="sort" data-sort="avatar">Avatar</th>
                                        <th scope="col" class="sort" data-sort="nickname">Nickname</th>
                                        <th scope="col" class="sort" data-sort="user_id">Game ID</th>
                                        <th scope="col" class="sort" data-sort="desk">Fraction</th>
                                        <th scope="col" class="sort" data-sort="fraction">Change Time</th>
                                    </tr>
                                </thead>

                                <tbody class="list">
                                    <?php
                                        $index = 1;
                                        $page = request('page') ?? 1;
                                    ?>

                                    <?php $__currentLoopData = $scores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th>
                                            <button type="button" class="btn btn-secondary btn-sm"><?php if($page != 1): ?> <?php echo e((($page-1)*15)+$index); ?> <?php else: ?> <?php echo e($index); ?> <?php endif; ?></button>
                                        </th>
                                        <td class="media align-items-center">
                                            <a href="#" class="avatar rounded-circle mr-3">
                                            <img alt="Image placeholder" src="<?php echo e($score->player->avatar1); ?>">
                                            </a>
                                        </td>
                                        <td>
                                            <?php echo e($score->player->nickname1); ?>

                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-success btn-sm" href="<?php echo e(route('viewplayers', ['player' => $score->game_id])); ?>"><?php echo e($score->game_id); ?></button>
                                        </td>
                                        <td class="score">
                                        <i class="fa-solid fa-gem fa-xs"></i>&nbsp;<?php echo e($score->fraction); ?>

                                        </td>
                                        <td class="score">
                                        <?php echo e($score->created_at); ?>

                                        </td>
                                    </tr>
                                    <?php
                                    $index++;
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        
                        <!--Pagination Section-->
                        <div class="card-footer py-4">
                            <nav aria-label="...">
                                <ul class="pagination justify-content-end mb-0">
                                    
                                    <?php if($page != 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo e($page-1); ?>" tabindex="-1">
                                        <i class="fas fa-angle-left"></i>
                                        <span class="sr-only">Previous</span>
                                    </a>
                                </li>
                                <?php endif; ?>
                                
                                <?php
                                    $init = 1;
                                    $continues = 1;

                                    if($total_page == 1 || $total_page <= 3 && $page <= 3){
                                        $init = 1;
                                        $continues = $total_page;
                                    }elseif($total_page > 3 && $page <= 3){
                                        $init = 1;
                                        $continues = 3;
                                    }elseif($page == $total_page){
                                        $init = $page-3;
                                        $continues = $page-1;
                                    }else{
                                        $init = $page-2;
                                        $continues = $page;
                                    }
                                ?>

                                <?php for($i=$init;$i<=$continues;$i++): ?>
                                <li class="page-item <?php if($page == $i): ?> active <?php endif; ?>">
                                    <a class="page-link" href="?page=<?php echo e($i); ?>"><?php echo e($i); ?></a>
                                </li>
                                <?php endfor; ?>

                                <?php if($total_page>4): ?>
                                <li class="page-item <?php if($page == $total_page): ?> active <?php endif; ?>">
                                    <a class="page-link" href="?page=<?php echo e($total_page); ?>"><?php echo e($total_page); ?></a>
                                </li>
                                <?php endif; ?>
                                
                                <?php if($page != $total_page): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo e($page+1); ?>">
                                        <i class="fas fa-angle-right"></i>
                                        <span class="sr-only">Next</span>
                                    </a>
                                </li>
                                <?php endif; ?>

                                </ul>
                            </nav>
                        </div>
                        
                    </div>
                </div>
            </div>
            <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        
    </div>
    

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.extension.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app-score-utilization', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/koonekne/gopa.koonek.net/resources/views/pages/score-utilization.blade.php ENDPATH**/ ?>