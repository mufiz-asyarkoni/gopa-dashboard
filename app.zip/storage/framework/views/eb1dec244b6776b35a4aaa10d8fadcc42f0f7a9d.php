

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('layouts.headers.cards', ['total_player' => $total_player], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="container-fluid mt--7">
        <div class="row">
            <div class="col-xl-8 mb-5 mb-xl-2">
                <div class="card bg-gradient-default shadow">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="text-uppercase text-light ls-1 mb-1">Overview</h6>
                                <h2 class="text-white mb-0">Desks Traffic</h2>
                            </div>
                            <div class="col">
                                <ul class="nav nav-pills justify-content-end">
                                    <li class="nav-item mr-2 mr-md-0" data-toggle="chart" data-target="#chart-sales" data-update='{"data":{"datasets":[{"data":[0, 20, 10, 30, 15, 40, 20, 60, 60]}]}}' data-prefix="" data-suffix="k">
                                        <a href="#" class="nav-link py-2 px-3 active" data-toggle="tab">
                                            <span class="d-none d-md-block">Month</span>
                                            <span class="d-md-none">M</span>
                                        </a>
                                    </li>
                                    <li class="nav-item" data-toggle="chart" data-target="#chart-sales" data-update='{"data":{"datasets":[{"data":[0, 20, 5, 25, 10, 30, 15, 40, 40]}]}}' data-prefix="" data-suffix="k">
                                        <a href="#" class="nav-link py-2 px-3" data-toggle="tab">
                                            <span class="d-none d-md-block">Week</span>
                                            <span class="d-md-none">W</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- Chart -->
                        <div class="chart">
                            <!-- Chart wrapper -->
                            <canvas id="chart-sales" class="chart-canvas"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="card shadow">
                    <div class="card-header bg-transparent">
                        <div class="row align-items-center">
                            <div class="col">
                                <h6 class="text-uppercase text-muted ls-1 mb-1">Performance</h6>
                                <h2 class="mb-0">Total Admin Fee</h2>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <!-- Chart -->
                        <div class="chart">
                            <canvas id="chart-orders" class="chart-canvas"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    
    <div class="container-fluid mt-5 mt-xl-4">
        <div class="header-body">
            <div class="row mb-xl-4">
                <div class="col-xl-12 col-lg-6">
                    <div class="card shadow bg-gradient-primary card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h4 class="card-title text-uppercase text-muted mt-3 text-white">Player Admin Fee Details</h4>
                                </div>
                                <div class="col-auto">
                                    <div  class="icon icon-shape bg-yellow text-white rounded-circle shadow mt-1">
                                        <a class="nav-link" href="<?php echo e(route('configuration')); ?>">
                                        <i class="fas fa-dollar-sign"></i>
                                        </a>
                                    </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Card Stats Player Admin Fee -->
            <div class="row">
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (1)</h5>
                                    <?php $__currentLoopData = $admin_fee1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;<?php echo e($fee1->fee_admin1); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-primary text-white rounded-circle shadow">
                                        <i class="fas fa-1"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (2)</h5>
                                    <?php $__currentLoopData = $admin_fee2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;<?php echo e($fee2->fee_admin2); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-pink text-white rounded-circle shadow">
                                        <i class="fas fa-2"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (3)</h5>
                                    <?php $__currentLoopData = $admin_fee3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;<?php echo e($fee3->fee_admin3); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-info text-white rounded-circle shadow">
                                        <i class="fa-solid fa-3"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-xl-4">
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (4)</h5>
                                    <?php $__currentLoopData = $admin_fee4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;<?php echo e($fee4->fee_admin4); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-red text-white rounded-circle shadow">
                                        <i class="fas fa-4"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (5)</h5>
                                    <?php $__currentLoopData = $admin_fee5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee5): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;<?php echo e($fee5->fee_admin5); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-green text-white rounded-circle shadow">
                                        <i class="fas fa-5"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (6)</h5>
                                    <?php $__currentLoopData = $admin_fee6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee6): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;<?php echo e($fee6->fee_admin6); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-orange text-white rounded-circle shadow">
                                        <i class="fa-solid fa-6"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row mt-xl-4">
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (7)</h5>
                                    <?php $__currentLoopData = $admin_fee7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee7): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;<?php echo e($fee7->fee_admin7); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-dark text-white rounded-circle shadow">
                                        <i class="fas fa-7"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (8)</h5>
                                    <?php $__currentLoopData = $admin_fee8; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee8): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;<?php echo e($fee8->fee_admin8); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-gray text-white rounded-circle shadow">
                                        <i class="fas fa-8"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-6">
                    <div class="card shadow card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Admin Fee Player (9)</h5>
                                    <?php $__currentLoopData = $admin_fee9; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee9): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="h2 font-weight-bold mb-0"><i class="fa-solid fa-gem fa-xs"></i>&nbsp;<?php echo e($fee9->fee_admin9); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-purple text-white rounded-circle shadow">
                                        <i class="fa-solid fa-9"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('layouts.footers.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
         
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="<?php echo e(asset('argon')); ?>/vendor/chart.js/dist/Chart.extension.js"></script>
            <script src="https://argon-dashboard-pro-laravel.creative-tim.com/argon/vendor/chart.js/dist/Chart.min.js"></script>
        <script
            src="https://argon-dashboard-pro-laravel.creative-tim.com/argon/vendor/chart.js/dist/Chart.extension.js"></script>
        <script src="https://argon-dashboard-pro-laravel.creative-tim.com/argon/vendor/chart.js/dist/Chart.min.js"></script>
        <script
            src="https://argon-dashboard-pro-laravel.creative-tim.com/argon/vendor/chart.js/dist/Chart.extension.js"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/koonekne/gopa.koonek.net/resources/views/dashboard.blade.php ENDPATH**/ ?>