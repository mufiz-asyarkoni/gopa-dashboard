<?php
header("refresh: 0; https://gopa.koonek.net/public/");
?>