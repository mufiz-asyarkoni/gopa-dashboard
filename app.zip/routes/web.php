<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Players2Controller;
use App\Http\Controllers\StatementController;
use App\Http\Controllers\GroupingController;
use App\Http\Controllers\BlackListController;
use App\Http\Controllers\HistoryController;
use App\Http\Controllers\GameDetailsController;
use App\Http\Controllers\ScoreUtilizationController;
use App\Http\Controllers\FeeAdminController;
use App\Http\Controllers\ConfigurationController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Auth::routes();

Route::group(['middleware' => 'auth'], function () {
	Route::resource('user', 'App\Http\Controllers\UserController', ['except' => ['show']]);
	Route::get('profile', ['as' => 'profile.edit', 'uses' => 'App\Http\Controllers\ProfileController@edit']);
	Route::put('profile', ['as' => 'profile.update', 'uses' => 'App\Http\Controllers\ProfileController@update']);
	Route::put('profile/password', ['as' => 'profile.password', 'uses' => 'App\Http\Controllers\ProfileController@password']);
	
     //route Statements
	 Route::get('cron-statement', [StatementController::class, 'cron']);
	 Route::get('statements', [StatementController::class, 'index'])->name('statements'); //menampilkan daftar statements yang terindeks
	 Route::get('viewstatements/{statement}', [StatementController::class, 'show'])->name('viewstatements'); //menampilkan satuan data sebuah statements
	 Route::post('statements/delete/{statement}', [StatementController::class, 'destroy']); //menghapus detail data statements

	 //route Players
	 Route::get('players', [Players2Controller::class, 'index'])->name('players'); //menampilkan daftar player
	 Route::get('addplayers', [Players2Controller::class, 'create'])->name('addplayers'); //membuka halaman add player 
	 Route::post('storeplayer', [Players2Controller::class, 'store'])->name('createplayer'); //menjalankan fungsi add player
	 Route::get('viewplayers/{player}', [Players2Controller::class, 'show'])->name('viewplayers'); //menampilkan data per satu player
	 Route::get('gameid/{player}', [Players2Controller::class, 'gameid'])->name('gameid'); //menampilkan data per satu player
	 Route::get('editplayers/{player}', [Players2Controller::class, 'edit'])->name('editplayers'); //membuka halaman edit player untuk setiap satu player
	 Route::put('player/update/{player}', [Players2Controller::class, 'update'])->name('player.update'); //menjalankan fungsi update player
	 Route::post('player/delete/{player}', [Players2Controller::class, 'destroy']); //menjalankan fungsi hapus player

	 //route Grouping 
	 Route::get('grouping', [GroupingController::class, 'index'])->name('grouping'); //menampilkan daftar player berdasarkan grup
	 Route::post('storegrouping', [GroupingController::class, 'store'])->name('storegrouping'); //menjalankan fungsi add grup baru
	 Route::post('addgrouping', [GroupingController::class, 'add'])->name('addgrouping'); //menjalankan fungsi menambahkan player ke grup
	 Route::post('removegrouping', [GroupingController::class, 'remove'])->name('rmgrouping'); //menjalankan fungsi menghapus player dari grup
	 Route::post('dropgrouping', [GroupingController::class, 'drop'])->name('dropgrouping'); //menjalankan fungsi menghapus grup

	 //route Blacklist 
	 Route::get('blacklist', [BlackListController::class, 'index'])->name('blacklist'); //menampilkan daftar player yang telah blacklist sementara
	 
	 //route History
	 Route::get('history', [HistoryController::class, 'index'])->name('history'); //menampilkan catatan akumulasi historis setiap player
	 
	 //route Game Details
	 Route::get('gamedetails', [GameDetailsController::class, 'index'])->name('gamedetails'); //menampilkan catatan historis permainan setiap player

	 //route Score Utilization
	 Route::get('score-utilization', [ScoreUtilizationController::class, 'index'])->name('score-utilization'); //menampilkan catatan historis perubahan score setiap player
	 
	 //route Configuration
	 Route::get('configuration', [ConfigurationController::class, 'index'])->name('configuration'); //menampilkan halaman konfigurasi website
	 Route::put('configuration/update/{fee_admin}', [FeeAdminController::class, 'update'])->name('configuration.update'); //menjalankan fungsi update fee admin
	 
	//route Room ID Generator
	Route::get('ridgenetaror', function () {return view('pages.ridgenetaror');})->name('ridgenetaror'); //menjalankan fungsi rid_list generator
	 
});


