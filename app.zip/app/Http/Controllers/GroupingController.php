<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Players2;
use App\Models\Grouping;
use App\Models\GroupingPlayer;
use Illuminate\Support\Facades\Http;

class GroupingController extends Controller
{
    public function index()
    {
        $total_page = 1;
        $group_q = request('group');
        $search = request('search');
        $count_player = Players2::count();
        $group = Grouping::get();
        $group_player = $group_q ? GroupingPlayer::where('group_id', $group_q)->get() : null;
        if($search){
            $players2 = Players2::where('game_id1', $search)->orWhere('nickname1', $search)->orWhere('marker1', $search)->get()->groupBy('nickname1');
            return view('pages.grouping', compact('players2', 'count_player', 'total_page', 'group', 'group_player'));
        }

        $total_page = $group_player ? GroupingPlayer::paginate(15)->lastPage() : Players2::paginate(15)->lastPage();
        $players2 = Players2::paginate(15)->groupBy('nickname1');

        return view('pages.grouping', compact('players2', 'count_player', 'total_page', 'group', 'group_player'));
    }

    public function store(Request $request){
        if(!$request->group_name)
            return back()->withStatus(__('Write the name of the group you want to create first.'));

        $grouping = new Grouping();
        $grouping->name = $request->group_name;
        $grouping->save();

        return redirect('grouping');
    }

    public function add(Request $request){
        if(!$request->selected)
            return back()->withStatus(__('Select the player you want to add to the group first.'));

        foreach($request->selected as $game_id){
            $grouping = new GroupingPlayer();
            $grouping->game_id = $game_id;
            $grouping->group_id = $request->group_selection;
            $grouping->save();
        }

        return redirect('grouping');
    }
    
    public function remove(Request $request){
        if(!$request->selected)
            return back()->withStatus(__('Select the player you want to remove from the group first.'));

        foreach($request->selected as $game_id)
            GroupingPlayer::where('game_id', $game_id)->delete();

        return redirect('grouping');
    }
    
    public function drop(Request $request){
        $grouping = Grouping::find($request->group);
        if(!$grouping)
            return back()->withStatus(__('Select the group you want to delete first.'));

        GroupingPlayer::where('group_id', $grouping->id)->delete();
        $grouping->delete();
        return redirect('grouping');
    }
}
