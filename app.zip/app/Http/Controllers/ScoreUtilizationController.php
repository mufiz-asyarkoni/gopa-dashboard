<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ScoreUtilization;
use App\Models\Players2;

class ScoreUtilizationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $total_page = 1;
        $search = request('search');
        if($search){
            $scores = ScoreUtilization::where('game_id', $search)->get();
            if(count($scores) == 0){
                $scores = Players2::where('nickname1', $search)->first();
                $scores = ScoreUtilization::where('game_id', $scores->game_id1)->orderBy('created_at', 'DESC')->get();
            }

            return view('pages.score-utilization', compact('scores', 'total_page'));
        }

        $scores = ScoreUtilization::orderBy('created_at', 'DESC')->paginate(15);
        $total_page = ScoreUtilization::paginate(15)->lastPage();
        return view('pages.score-utilization', compact('scores', 'total_page'));
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\ScoreUtilization  $scoreUtilization
     * @return \Illuminate\Http\Response
     */
    public function show(ScoreUtilization $scoreUtilization)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\ScoreUtilization  $scoreUtilization
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ScoreUtilization $scoreUtilization)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\ScoreUtilization  $scoreUtilization
     * @return \Illuminate\Http\Response
     */
    public function destroy(ScoreUtilization $scoreUtilization)
    {
        //
    }
}
