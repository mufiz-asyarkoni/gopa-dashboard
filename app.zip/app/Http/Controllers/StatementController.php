<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Http;
use Illuminate\Http\Request;
use App\Models\Statement;
use App\Models\Room;
use App\Models\Players2;
use App\Models\History;
use App\Models\FeeAdmin;
use App\Models\GameDetails;
use App\Models\StatementPlayer;
use Illuminate\Support\Carbon;

class StatementController extends Controller
{
    public function generateRID(){
        $userLength1 = 1; //mendefinisikan panjang string (1)
        $userLength2 = 4; //mendefinisikan panjang string (2)
        $userLength3 = 1; //mendefinisikan panjang string (3)
        $userLength4 = 2; //mendefinisikan panjang string (4)
        $permitted_chars1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; //mendefinisikan string set pertama
        $permitted_chars2 = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ"; //mendefinisikan string set kedua
        $permitted_chars3 = "123"; //mendefinisikan string set ketiga
        $permitted_chars4 = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ"; //mendefinisikan string set keempat
        
        //mendapatkan calon user_rid dari charset untuk divalidasi
        $getUserRID = '1C'.substr(str_shuffle($permitted_chars1), 0, $userLength1).substr(str_shuffle($permitted_chars2), 0, $userLength2).'06'.substr(str_shuffle($permitted_chars3), 0, $userLength3).substr(str_shuffle($permitted_chars4), 0, $userLength4); 
        return $getUserRID;
    }

    public function ridToTxt(){
        for($i=0;$i<=2000000;$i++){
            $fp = fopen('data.txt', 'a');//opens file in append mode.
            fwrite($fp, $this->generateRID()."\n");
            fclose($fp);
        }
    }
 
    public function cron(){
        $get_rid = $this->generateRID();

        $fp = fopen('eliminate.txt', 'rb');
        $myString = fread($fp, filesize('eliminate.txt'));
        if(!strstr( $myString, $get_rid)){
            $response = Http::asForm()->post('http://www.gongpaa.com:80/apigame/getUnionRecord2', [
                "rid" => "18X0GK2333YN",
                "sign" => "24704e8efde4badb7ee57207c8959f11",
                "timestamp" => 1658660609,
                "user" => "wx_o1_rwwrv3l_GiIaIR930QDMDXdkc",
                "uid" => "994988",
                "game_type" => "thirteen-water",
                "rid_list" => $get_rid
            ]);

            $response = $response['lists'];
            if(count($response) == 0){
                $fp = fopen('eliminate.txt', 'a');//opens file in append mode  
                fwrite($fp, "$get_rid\n");  
                fclose($fp);
            }else{
                $fp = fopen('good.txt', 'a');//opens file in append mode  
                fwrite($fp, "$get_rid\n");  
                fclose($fp);
            }
        }

        return response()->json(['msg'=> 'Cron Updated']);
    }

    public function statement_parse(Request $request){
        $room_id = Room::first()->room_id;
        $processed = [];
        
        foreach($request['lists'] as $response){
            $log_detail = json_decode($response['log_detail'], true);
            if(Statement::where('desk_no', $log_detail['desk_no'])->first()) continue;

            $statement = new Statement;
            $statement->room_id = $room_id;
            $statement->desk_no = $log_detail['desk_no'];
            $statement->create_time = date('Y-m-d H:i:s', $response['create_time']);
            $statement->end_time = date('Y-m-d H:i:s', $response['create_time']); //sementara
            $statement->status = $response['oper_name'] == "system" ? 'completed' : 'abortive';
            $statement->save();

            $score_track = [];
            $score = $log_detail['score'];
            $score_rank = collect($score)->sortDesc()->keys()->toArray();
            foreach($log_detail['record_list'] as $round => $list)
                foreach($list['score'] as $key => $idx)
                    $score_track[$key][$round] = $idx;

            foreach($log_detail['users'] as $key => $detail){
                $keys = $key+1;
                $game = new GameDetails;
                $game->game_id = $detail['account_uid'];
                $game->player_ip = $detail['client_ip'];
                foreach($score_track["idx$keys"] as $u => $val){
                    $i = "score_".($u+1);
                    $game->{$i} = $val;
                }
                $fee_admin = "fee_admin".(array_search("idx$keys", $score_rank)+1);
                $game->fee_admin = (int)(FeeAdmin::select($fee_admin)->first()->{$fee_admin});
                $game->score_final = (int)($score["idx$keys"]) - $game->fee_admin;
                $game->desk_no = $log_detail['desk_no'];
                $game->end_time = date('Y-m-d H:i:s', $response['create_time']); //sementara
                $game->save();

                $statement_player = new StatementPlayer;
                $statement_player->game_id = $detail['account_uid'];
                $statement_player->score = $game->score_final;
                $statement_player->ip = $detail['client_ip'];
                $statement_player->room_id = $room_id; //sementara
                $statement_player->desk_id = $log_detail['desk_no'];
                $statement_player->save();

                $history = History::where('game_id', $detail['account_uid'])->first();
                if(!$history)
                    $history = new History;
                    
                $history->game_id = $history->game_id ?? $detail['account_uid'];
                $history->total_desks = $history->total_desks + 1;
                $history->total_profit_loss = $history->total_profit_loss + $game->score_final;
                $history->total_fee_admin = $history->total_fee_admin + $game->fee_admin;
                $history->save();
                
                $player = Players2::where('game_id1', $detail['account_uid'])->first();
                if($player){
                    $player->score1 = $history->total_profit_loss;
                    $player->desks1 = $history->total_desks;
                    $player->save();
                }

                array_push($processed, $log_detail['desk_no']);
            }
        }

        return response()->json(['message'=>'success', 'processed_desk'=>$processed], 200);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $create_time = request('create_time');
        $end_time = request('end_time');
        $desk_no = request('desk_no');
        $room_id = request('room_id');
        $statements = Statement::orderBy('end_time', 'DESC');
        if($create_time && $end_time)
            $statements = Statement::whereBetween('create_time', [Carbon::parse($create_time), Carbon::parse($end_time)])->whereBetween('end_time', [Carbon::parse($create_time), Carbon::parse($end_time)]);
            
        if($desk_no)
            $statements = Statement::where('desk_no', $desk_no);
            
        $statements = $statements->paginate(15);
        $total_page = Statement::paginate(15)->lastPage();
        return view('pages.statements', compact('statements', 'total_page'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show(Statement $statement)
    {
        $statement_player = StatementPlayer::where('desk_id', $statement->desk_no)->get();
        $game_details = GameDetails::where('desk_no', $statement->desk_no)->get();
        $score = [];
        $game_id = [];
        $score_total = 10;
        foreach($game_details as $key => $detail){
            for($i = 1; $i <= $score_total; $i++){
                $score_index = "score_".$i;
                if($detail->{$score_index} == null)
                    $score_total = $i-1;
                
                $score[$i][$key] = $detail->{$score_index};
            }
            $game_id[$key] = $detail->game_id;
        }

        return view('pages.viewstatements', compact('statement_player', 'score', 'game_id', 'score_total'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Statement $statement)
    {
        StatementPlayer::where('desk_no', $statement->desk_no)->delete();
        
        $players = GameDetails::where('desk_no', $statement->desk_no)->get();
        foreach($players as $player){
            GameDetails::find($player->id)->delete();
            
            $history = History::where('game_id', $player->game_id)->first();
            $history->total_profit_loss = $history->total_profit_loss - $player->score_final;
            $history->save();

            $player = Players2::where('game_id', $player->game_id)->first();
            $player->score1 = $history->total_profit_loss;
            $player->desks1 = $history->total_desks - 1;
            $player->save();
        }
        $statement->delete();
        return redirect('/statements')->with('Success','Statements Deleted successfully!');
    }
}
