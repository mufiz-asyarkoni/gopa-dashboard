<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\History;
use App\Models\Statement;
use App\Models\Players2;
use Illuminate\Support\Facades\Http;

class HistoryController extends Controller
{
    public function index()
    {
        $total_page = 1;
        $search = request('search');
        $count_player = History::count();
        $total_fee = History::sum('total_fee_admin');
        $total_desks = Statement::count();
        $total_profit = History::sum('total_profit_loss');

        if($search){
            $players2 = History::where('game_id', $search)->get();
            $marker = Players2::where('marker1', $search)->get();
            return view('pages.history', compact('players2', 'marker', 'count_player', 'total_page', 'total_fee', 'total_desks', 'total_profit'));
        }

        $total_page = History::paginate(15)->lastPage();
        $players2 = History::paginate(15);
        return view('pages.history', compact('players2', 'count_player', 'total_page', 'total_fee', 'total_desks', 'total_profit'));
    }
}
