<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Players2;
use App\Models\Grouping;
use App\Models\GroupingPlayer;
use App\Models\ScoreUtilization;
use App\Models\StatementPlayer;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Carbon;
use Session;

class Players2Controller extends Controller
{
    public function index()
    {
        $total_page = 1;
        $group_q = request('group');
        $search = request('search');
        $total_score = Players2::sum('score1');
        $count_player = Players2::count();
        $group = Grouping::get();
        $group_player = $group_q ? GroupingPlayer::where('group_id', $group_q)->get() : null;
        if($search){
            $players2 = Players2::where('game_id1', $search)->orWhere('nickname1', $search)->orWhere('marker1', $search)->get()->groupBy('nickname1');
            return view('pages.players', compact('players2', 'count_player', 'total_page', 'group', 'group_player', 'total_score'));
        }

        $total_page = $group_player ? GroupingPlayer::paginate(15)->lastPage() : Players2::paginate(15)->lastPage();
        $players2 = Players2::paginate(15)->groupBy('nickname1');
        return view('pages.players', compact('players2', 'count_player', 'total_page', 'group', 'group_player', 'total_score'));
    }

    public function create()
    {
        return view('pages.addplayers');
    }

    public function store(Request $request)
    {
        $response = Http::asForm()->post('http://ywt2.gongpaa.com:80/apigame/getUserHead', [
            'accout_list' => $request->telephone,
        ]);
        
        if($response->failed())
           return back()->withStatus(__('Unable to add new player data, please check the player id again.')); 

        $param = $response->json()['list'][0];

        if(!$param['name'] && !$param['headimgurl'] || Players2::where('game_id1', $param['accout_uid'])->first())
            return back()->withErrors(['Unable to add new player data, please check the player id again.']); 

        $players2 = new Players2();
        $players2->avatar1 = urldecode($param['headimgurl']);
        $players2->nickname1 = urldecode($param['name']);
        $players2->marker1 = '-';
        $players2->game_id1 = $param['accout_uid'];
        $players2->desks1 = '0';
        $players2->quota1 = '0';
        $players2->score_today1 = '0';
        $players2->score1 = '0';
        $players2->feeadmin1 = '0';
        $players2->realname1 = '0';
        $players2->usercode1 = '0';
        $players2->telephone1 = '0';
        $players2->wechat1 = '0';
        $players2->user_auth1 = '0';
        $players2->pass_auth1 = '0';

        $players2->save();
        return back()->withStatus(__('New Player successfully created.'));
    }

    public function show(Players2 $player)
    {
        $from = Carbon::createFromTimeString('00:00')->startOfDay();
        $to = Carbon::createFromTimeString('00:00')->endOfDay();
        $score_statement = StatementPlayer::where('game_id', $player->game_id1)->whereBetween('created_at', [$from, $to])->sum('score');
        $desk_today = StatementPlayer::where('game_id', $player->game_id1)->whereBetween('created_at', [$from, $to])->count();
        $score_today = $score_statement;

        return view('pages.viewplayers', compact('player', 'score_today', 'desk_today'));
    }

    public function edit(Players2 $player)
    {
        return view('pages.editplayers', compact('player'));
    }
    
    public function gameid(Players2 $player)
    {
        return view('pages.gameid', compact('player'));
    }

    public function update(Request $request, Players2 $player)
    {
        $player->nickname1 = $request->nickname1;
        $player->marker1 = $request->marker1;
        $player->score1 = $request->score1 ? intval($player->score1) + intval($request->score1) : $player->score1;
        $player->notes1 = $request->notes1;
        $player->save();

        if($request->score1){
            $score_util = new ScoreUtilization;
            $score_util->game_id = $player->game_id1;
            $score_util->fraction = $request->score1;
            $score_util->save();
        }

        return back()->withStatus(__('Data Player successfully updated.'));
    }

    public function destroy(Players2 $player)
    {
        $player->delete();
        return back()->withStatus(__('Data Player successfully deleted.'));
    }
}
