<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\FeeAdmin;

class FeeAdminController extends Controller
{
   
   public function update(Request $request, FeeAdmin $fee_admin)
    {
        $fee_admin->fee_admin1 = $request->fee_admin1;
        $fee_admin->fee_admin2 = $request->fee_admin2;
        $fee_admin->fee_admin3 = $request->fee_admin3;
        $fee_admin->fee_admin4 = $request->fee_admin4;
        $fee_admin->fee_admin5 = $request->fee_admin5;
        $fee_admin->fee_admin6 = $request->fee_admin6;
        $fee_admin->fee_admin7 = $request->fee_admin7;
        $fee_admin->fee_admin8 = $request->fee_admin8;
        $fee_admin->fee_admin9 = $request->fee_admin9;
        $fee_admin->save();

        return back()->withStatus(__('Admin fee successfully updated.'));
    }
}
