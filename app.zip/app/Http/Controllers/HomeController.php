<?php

namespace App\Http\Controllers;

use App\Models\Players2;
use App\Models\Grouping;
use App\Models\Room;
use App\Models\Statement;
use App\Models\StatementPlayer;
use App\Models\FeeAdmin;
use App\Models\History;
use Illuminate\Support\Carbon;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        /*indeks konfigurasi fee admin*/
        $admin_fee1 = FeeAdmin::select('id','fee_admin1')->get();
        $admin_fee2 = FeeAdmin::select('id','fee_admin2')->get();
        $admin_fee3 = FeeAdmin::select('id','fee_admin3')->get();
        $admin_fee4 = FeeAdmin::select('id','fee_admin4')->get();
        $admin_fee5 = FeeAdmin::select('id','fee_admin5')->get();
        $admin_fee6 = FeeAdmin::select('id','fee_admin6')->get();
        $admin_fee7 = FeeAdmin::select('id','fee_admin7')->get();
        $admin_fee8 = FeeAdmin::select('id','fee_admin8')->get();
        $admin_fee9 = FeeAdmin::select('id','fee_admin9')->get();
        
        /*indeks total grup*/
        $total_group = Grouping::count();
        
        /*indeks total pemain*/
        $total_player = Players2::count();
        
        /*indeks total room*/
        $total_room = Room::count();
        
        /*indeks total desk/statements*/
        $total_desks = Statement::count();

        /*indeks total score*/
        $from = Carbon::createFromTimeString('00:00')->startOfDay();
        $to = Carbon::createFromTimeString('00:00')->endOfDay();
        $total_today_fee = History::whereBetween('created_at', [$from, $to])->sum('total_fee_admin');

        /*return dashboard.blade.php*/
        return view('dashboard', compact('total_player', 'total_group', 'total_room', 'total_desks', 'total_today_fee', 'admin_fee1', 'admin_fee2', 'admin_fee3', 'admin_fee4', 'admin_fee5', 'admin_fee6', 'admin_fee7', 'admin_fee8', 'admin_fee9'));
    }
}
