<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\GameDetails;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Http;

class GameDetailsController extends Controller
{
    public function index()
    {
        $create_time = request('create_time');
        $end_time = request('end_time');
        $total_page = 1;
        $search = request('search') ?? null;
        $count_player = GameDetails::count();
        if($search){
            $players2 = GameDetails::where('game_id', $search)->orderBy('end_time', 'DESC')->get();
            return view('pages.gamedetails', compact('players2', 'count_player', 'total_page'));
        }
        
        if($create_time && $end_time){
            $players2_raw = GameDetails::whereBetween('end_time', [Carbon::parse($create_time), Carbon::parse($end_time)])->orderBy('end_time', 'DESC');
            $total_page = $players2_raw->paginate(15)->lastPage();
            $players2 = $players2_raw->paginate(15);
            return view('pages.gamedetails', compact('players2', 'count_player', 'total_page'));
        }

        $total_page = GameDetails::paginate(15)->lastPage();
        $players2 = GameDetails::orderBy('end_time', 'DESC')->paginate(15);
        return view('pages.gamedetails', compact('players2', 'count_player', 'total_page'));
    }
}
