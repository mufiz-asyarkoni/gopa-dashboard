<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Players2;
use App\Models\GameDetails;

class StatementPlayer extends Model
{
    use HasFactory;

    public function player()
    {
        return $this->hasOne(Players2::class, 'game_id1', 'game_id');
    }

    public function game_detail()
    {
        return $this->hasMany(GameDetails::class, 'game_id', 'game_id');
    }
}
