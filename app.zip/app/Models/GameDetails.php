<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Players2;

class GameDetails extends Model
{
    use HasFactory;

    public function player()
    {
        return $this->hasOne(Players2::class, 'game_id1', 'game_id');
    }
}
